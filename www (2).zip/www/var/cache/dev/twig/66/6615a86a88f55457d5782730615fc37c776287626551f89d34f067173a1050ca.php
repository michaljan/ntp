<?php

/* NTPBundle:File:files_display.html.twig */
class __TwigTemplate_36fab752656068d2f4b432b50d0b55f5840e7e38f2d098de978e18a437a06d2d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "NTPBundle:File:files_display.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_112bcee4c86f0ccb4ced7719257dec752d3d9cac7cf870aeb90d5cf7c3706a36 = $this->env->getExtension("native_profiler");
        $__internal_112bcee4c86f0ccb4ced7719257dec752d3d9cac7cf870aeb90d5cf7c3706a36->enter($__internal_112bcee4c86f0ccb4ced7719257dec752d3d9cac7cf870aeb90d5cf7c3706a36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NTPBundle:File:files_display.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_112bcee4c86f0ccb4ced7719257dec752d3d9cac7cf870aeb90d5cf7c3706a36->leave($__internal_112bcee4c86f0ccb4ced7719257dec752d3d9cac7cf870aeb90d5cf7c3706a36_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_2eaeb441122cec4387bbd3caa9babed0bb15d27d3a54e56bc8e5430a88b7d8a0 = $this->env->getExtension("native_profiler");
        $__internal_2eaeb441122cec4387bbd3caa9babed0bb15d27d3a54e56bc8e5430a88b7d8a0->enter($__internal_2eaeb441122cec4387bbd3caa9babed0bb15d27d3a54e56bc8e5430a88b7d8a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <table class=\"table table-striped\">

        <thead>
            <tr>
                <th>#</th>
                <th>Plan name</th>
                <th>File name</th>
                <th>Plan date</th>
                <th>Uploaded date</th>
                <th>Action</th>
            </tr>
        </thead>
        ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["fileProcessed"]) ? $context["fileProcessed"] : $this->getContext($context, "fileProcessed")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 16
            echo "            <tr>
                <td>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getId", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getName", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getPath", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "getPlanDate", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "getUploadedAt", array()), "d-m-Y H:i"), "html", null, true);
            echo "</td>
                <td>
                    <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("process_csv", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-success\">Process</a>
                    <a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("delete_csv", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a>
                </td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "
    </table>
";
        
        $__internal_2eaeb441122cec4387bbd3caa9babed0bb15d27d3a54e56bc8e5430a88b7d8a0->leave($__internal_2eaeb441122cec4387bbd3caa9babed0bb15d27d3a54e56bc8e5430a88b7d8a0_prof);

    }

    public function getTemplateName()
    {
        return "NTPBundle:File:files_display.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 29,  86 => 24,  82 => 23,  77 => 21,  73 => 20,  69 => 19,  65 => 18,  61 => 17,  58 => 16,  54 => 15,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <table class="table table-striped">*/
/* */
/*         <thead>*/
/*             <tr>*/
/*                 <th>#</th>*/
/*                 <th>Plan name</th>*/
/*                 <th>File name</th>*/
/*                 <th>Plan date</th>*/
/*                 <th>Uploaded date</th>*/
/*                 <th>Action</th>*/
/*             </tr>*/
/*         </thead>*/
/*         {% for item in fileProcessed %}*/
/*             <tr>*/
/*                 <td>{{ item.getId }}</td>*/
/*                 <td>{{ item.getName }}</td>*/
/*                 <td>{{ item.getPath }}</td>*/
/*                 <td>{{ item.getPlanDate|date('d-m-Y') }}</td>*/
/*                 <td>{{ item.getUploadedAt|date('d-m-Y H:i') }}</td>*/
/*                 <td>*/
/*                     <a href="{{ path('process_csv',{ id: item.id }) }}" class="btn btn-success">Process</a>*/
/*                     <a href="{{ path('delete_csv',{ id: item.id }) }}" class="btn btn-danger">Delete</a>*/
/*                 </td>*/
/* */
/*             </tr>*/
/*         {% endfor %}*/
/* */
/*     </table>*/
/* {% endblock %}*/
/* */
