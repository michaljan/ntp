<?php

/* NTPBundle::base.html.twig */
class __TwigTemplate_06fbf1bae7e1f89e463dec2b171adae9ebcde8e4f7aa45021f5787935e89e302 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'documentReady' => array($this, 'block_documentReady'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b3771a45e803bc53b90e7828def9e799fa64cf47f76f0d29ba8fbe6125813ec4 = $this->env->getExtension("native_profiler");
        $__internal_b3771a45e803bc53b90e7828def9e799fa64cf47f76f0d29ba8fbe6125813ec4->enter($__internal_b3771a45e803bc53b90e7828def9e799fa64cf47f76f0d29ba8fbe6125813ec4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NTPBundle::base.html.twig"));

        // line 1
        echo "<!doctype html>
<!--[if lt IE 7]>      <html class=\"no-js lt-ie9 lt-ie8 lt-ie7\" lang=\"\"> <![endif]-->
<!--[if IE 7]>         <html class=\"no-js lt-ie9 lt-ie8\" lang=\"\"> <![endif]-->
<!--[if IE 8]>         <html class=\"no-js lt-ie9\" lang=\"\"> <![endif]-->
<!--[if gt IE 8]><!--> <html class=\"no-js\" lang=\"\"> <!--<![endif]-->
    <head>
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge,chrome=1\">
        <title>NTP SITE</title>
        <meta name=\"description\" content=\"\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        ";
        // line 12
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "999aeda_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_999aeda_0") : $this->env->getExtension('asset')->getAssetUrl("js/999aeda_part_1_modernizr-2.8.3.min_1.js");
            // line 13
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
        ";
            // asset "999aeda_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_999aeda_1") : $this->env->getExtension('asset')->getAssetUrl("js/999aeda_part_1_npm_2.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
        ";
            // asset "999aeda_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_999aeda_2") : $this->env->getExtension('asset')->getAssetUrl("js/999aeda_part_1_ntpcharts_3.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
        ";
        } else {
            // asset "999aeda"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_999aeda") : $this->env->getExtension('asset')->getAssetUrl("js/999aeda.js");
            echo "        <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
        ";
        }
        unset($context["asset_url"]);
        // line 15
        echo "        ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "1f10d61_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_1f10d61_0") : $this->env->getExtension('asset')->getAssetUrl("css/1f10d61_part_1_main_1.css");
            // line 16
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
        <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
        <link rel=\"stylesheet\" href=\"//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css\">
        ";
            // asset "1f10d61_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_1f10d61_1") : $this->env->getExtension('asset')->getAssetUrl("css/1f10d61_part_1_normalize_2.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
        <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
        <link rel=\"stylesheet\" href=\"//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css\">
        ";
            // asset "1f10d61_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_1f10d61_2") : $this->env->getExtension('asset')->getAssetUrl("css/1f10d61_part_1_normalize.min_3.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
        <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
        <link rel=\"stylesheet\" href=\"//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css\">
        ";
            // asset "1f10d61_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_1f10d61_3") : $this->env->getExtension('asset')->getAssetUrl("css/1f10d61_part_1_ntpmain_4.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
        <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
        <link rel=\"stylesheet\" href=\"//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css\">
        ";
        } else {
            // asset "1f10d61"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_1f10d61") : $this->env->getExtension('asset')->getAssetUrl("css/1f10d61.css");
            echo "        <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
        <link rel=\"stylesheet\" href=\"//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\">
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css\">
        <link rel=\"stylesheet\" href=\"//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css\">
        ";
        }
        unset($context["asset_url"]);
        // line 22
        echo "    </head>
    <body>
        <!--[if lt IE 8]>
            <p class=\"browserupgrade\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        ";
        // line 27
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 28
            echo "            <div class=\"row\">
                <div class=\"col-md-8\"></div>
                <div class=\"col-md-4\"><br/><p>Welcome: ";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo " <a href=\"";
            echo $this->env->getExtension('routing')->getPath("logout");
            echo "\">  Logout</a></p></div>
            </div>
            <div class=\"row\">
                <div class=\"col-md-1\"></div>
                <div class=\"col-md-10\">
                    <nav class=\"navbar navbar-default\">
                        <div class=\"container-fluid\">        
                            ";
            // line 37
            echo $this->env->getExtension('knp_menu')->render("NTPBundle:Builder:mainMenu", array("currentClass" => "active", "template" => "NTPBundle:Menu:knp_menu.html.twig"));
            echo "

                        </div>
                    ";
        }
        // line 41
        echo "            </div>
            <div class=\"col-md-1\"></div>    
        </nav>
    </div>
    <div class=\"row\">
        <div class=\"col-md-1\"></div>
        <div class=\"col-md-10\">
        ";
        // line 48
        $this->displayBlock('body', $context, $blocks);
        // line 49
        echo "    </div>
    <div class=\"row\">
        <div class=\"col-md-1\"></div>
        
    </div>
</div>


<script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js\"></script>
<script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js\"></script>
<script src=\"//code.jquery.com/ui/1.11.4/jquery-ui.js\"></script>
<script src=\"//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js\"></script>
<script src=\"//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js\"></script>

<script>
    \$(function () {
        \$(\"#form_planDate\").datepicker({
            dateFormat: \"dd-mm-yy\"
        });
        \$(\"#report_planDate\").datepicker({
            dateFormat: \"dd-mm-yy\"
        });
        
        \$(\"#range_startDate\").datepicker({
            dateFormat: \"dd-mm-yy\"
        });
        \$(\"#range_endDate\").datepicker({
            dateFormat: \"dd-mm-yy\"
        });
    });
</script>
<script>
    \$(document).ready(function () {
        ";
        // line 82
        $this->displayBlock('documentReady', $context, $blocks);
        // line 83
        echo "    });
</script>

<!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
<script>
    (function (b, o, i, l, e, r) {
        b.GoogleAnalyticsObject = l;
        b[l] || (b[l] =
                function () {
                    (b[l].q = b[l].q || []).push(arguments)
                });
        b[l].l = +new Date;
        e = o.createElement(i);
        r = o.getElementsByTagName(i)[0];
        e.src = '//www.google-analytics.com/analytics.js';
        r.parentNode.insertBefore(e, r)
    }(window, document, 'script', 'ga'));
    ga('create', 'UA-XXXXX-X', 'auto');
    ga('send', 'pageview');
</script>
</body>
</html>
";
        
        $__internal_b3771a45e803bc53b90e7828def9e799fa64cf47f76f0d29ba8fbe6125813ec4->leave($__internal_b3771a45e803bc53b90e7828def9e799fa64cf47f76f0d29ba8fbe6125813ec4_prof);

    }

    // line 48
    public function block_body($context, array $blocks = array())
    {
        $__internal_c8548b2c5dfb31a309620cf2c1e4d7c779363f21927fd5d73e33ea1cd7802c58 = $this->env->getExtension("native_profiler");
        $__internal_c8548b2c5dfb31a309620cf2c1e4d7c779363f21927fd5d73e33ea1cd7802c58->enter($__internal_c8548b2c5dfb31a309620cf2c1e4d7c779363f21927fd5d73e33ea1cd7802c58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_c8548b2c5dfb31a309620cf2c1e4d7c779363f21927fd5d73e33ea1cd7802c58->leave($__internal_c8548b2c5dfb31a309620cf2c1e4d7c779363f21927fd5d73e33ea1cd7802c58_prof);

    }

    // line 82
    public function block_documentReady($context, array $blocks = array())
    {
        $__internal_54b61a07a10c961d5fe3a4e8972420c65f8e219f01e070f5a606995c1f8a3525 = $this->env->getExtension("native_profiler");
        $__internal_54b61a07a10c961d5fe3a4e8972420c65f8e219f01e070f5a606995c1f8a3525->enter($__internal_54b61a07a10c961d5fe3a4e8972420c65f8e219f01e070f5a606995c1f8a3525_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "documentReady"));

        
        $__internal_54b61a07a10c961d5fe3a4e8972420c65f8e219f01e070f5a606995c1f8a3525->leave($__internal_54b61a07a10c961d5fe3a4e8972420c65f8e219f01e070f5a606995c1f8a3525_prof);

    }

    public function getTemplateName()
    {
        return "NTPBundle::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  244 => 82,  233 => 48,  204 => 83,  202 => 82,  167 => 49,  165 => 48,  156 => 41,  149 => 37,  137 => 30,  133 => 28,  131 => 27,  124 => 22,  72 => 16,  67 => 15,  41 => 13,  37 => 12,  24 => 1,);
    }
}
/* <!doctype html>*/
/* <!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->*/
/* <!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->*/
/* <!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->*/
/* <!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->*/
/*     <head>*/
/*         <meta charset="utf-8">*/
/*         <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">*/
/*         <title>NTP SITE</title>*/
/*         <meta name="description" content="">*/
/*         <meta name="viewport" content="width=device-width, initial-scale=1">*/
/*         {% javascripts '@NTPBundle/Resources/public/js/*' %}*/
/*         <script src="{{ asset_url }}"></script>*/
/*         {% endjavascripts %}*/
/*         {% stylesheets 'bundles/ntp/css/*' filter='cssrewrite' %}*/
/*         <link rel="stylesheet" href="{{ asset_url }}" />*/
/*         <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">*/
/*         <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">*/
/*         <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">*/
/*         <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">*/
/*         {% endstylesheets %}*/
/*     </head>*/
/*     <body>*/
/*         <!--[if lt IE 8]>*/
/*             <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>*/
/*         <![endif]-->*/
/*         {% if app.user %}*/
/*             <div class="row">*/
/*                 <div class="col-md-8"></div>*/
/*                 <div class="col-md-4"><br/><p>Welcome: {{app.user.username}} <a href="{{ path('logout')}}">  Logout</a></p></div>*/
/*             </div>*/
/*             <div class="row">*/
/*                 <div class="col-md-1"></div>*/
/*                 <div class="col-md-10">*/
/*                     <nav class="navbar navbar-default">*/
/*                         <div class="container-fluid">        */
/*                             {{ knp_menu_render('NTPBundle:Builder:mainMenu',  {'currentClass': 'active', 'template': 'NTPBundle:Menu:knp_menu.html.twig'}) }}*/
/* */
/*                         </div>*/
/*                     {% endif %}*/
/*             </div>*/
/*             <div class="col-md-1"></div>    */
/*         </nav>*/
/*     </div>*/
/*     <div class="row">*/
/*         <div class="col-md-1"></div>*/
/*         <div class="col-md-10">*/
/*         {% block body %}{% endblock %}*/
/*     </div>*/
/*     <div class="row">*/
/*         <div class="col-md-1"></div>*/
/*         */
/*     </div>*/
/* </div>*/
/* */
/* */
/* <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>*/
/* <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>*/
/* <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>*/
/* <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>*/
/* <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>*/
/* */
/* <script>*/
/*     $(function () {*/
/*         $("#form_planDate").datepicker({*/
/*             dateFormat: "dd-mm-yy"*/
/*         });*/
/*         $("#report_planDate").datepicker({*/
/*             dateFormat: "dd-mm-yy"*/
/*         });*/
/*         */
/*         $("#range_startDate").datepicker({*/
/*             dateFormat: "dd-mm-yy"*/
/*         });*/
/*         $("#range_endDate").datepicker({*/
/*             dateFormat: "dd-mm-yy"*/
/*         });*/
/*     });*/
/* </script>*/
/* <script>*/
/*     $(document).ready(function () {*/
/*         {% block documentReady %}{% endblock documentReady %}*/
/*     });*/
/* </script>*/
/* */
/* <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->*/
/* <script>*/
/*     (function (b, o, i, l, e, r) {*/
/*         b.GoogleAnalyticsObject = l;*/
/*         b[l] || (b[l] =*/
/*                 function () {*/
/*                     (b[l].q = b[l].q || []).push(arguments)*/
/*                 });*/
/*         b[l].l = +new Date;*/
/*         e = o.createElement(i);*/
/*         r = o.getElementsByTagName(i)[0];*/
/*         e.src = '//www.google-analytics.com/analytics.js';*/
/*         r.parentNode.insertBefore(e, r)*/
/*     }(window, document, 'script', 'ga'));*/
/*     ga('create', 'UA-XXXXX-X', 'auto');*/
/*     ga('send', 'pageview');*/
/* </script>*/
/* </body>*/
/* </html>*/
/* */
