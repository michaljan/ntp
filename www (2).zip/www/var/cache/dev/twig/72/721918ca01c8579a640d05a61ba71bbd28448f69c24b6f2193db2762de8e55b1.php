<?php

/* NTPBundle:File:files_history.html.twig */
class __TwigTemplate_c9516c307184200ecfe688d1d5b92b5b7c89f774a52d52a8434fba3bf5de6541 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "NTPBundle:File:files_history.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8ac7ae41425a0f258f4662ede4941d2aff7a5010c9b288fbff9977dd020041c9 = $this->env->getExtension("native_profiler");
        $__internal_8ac7ae41425a0f258f4662ede4941d2aff7a5010c9b288fbff9977dd020041c9->enter($__internal_8ac7ae41425a0f258f4662ede4941d2aff7a5010c9b288fbff9977dd020041c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NTPBundle:File:files_history.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8ac7ae41425a0f258f4662ede4941d2aff7a5010c9b288fbff9977dd020041c9->leave($__internal_8ac7ae41425a0f258f4662ede4941d2aff7a5010c9b288fbff9977dd020041c9_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_f3cfc25e00b8314b6a6acf5a7a0969454aaec1e2abf6681497399b3acdcc766e = $this->env->getExtension("native_profiler");
        $__internal_f3cfc25e00b8314b6a6acf5a7a0969454aaec1e2abf6681497399b3acdcc766e->enter($__internal_f3cfc25e00b8314b6a6acf5a7a0969454aaec1e2abf6681497399b3acdcc766e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <p class=\"text-center\">
    <ul class=\"list-inline\">
    ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["dateArray"]) ? $context["dateArray"] : $this->getContext($context, "dateArray")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 6
            echo "        ";
            if (($this->getAttribute($context["item"], "inarray", array()) == "True")) {
                // line 7
                echo "           <li><span class=\"label label-success\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "date", array()), "d-m-Y D"), "html", null, true);
                echo " </span></li>
        ";
            } else {
                // line 9
                echo "           <li><span class=\"label label-danger\">";
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "date", array()), "d-m-Y D"), "html", null, true);
                echo "</span></li>

        ";
            }
            // line 12
            echo "        ";
            if (($this->getAttribute($context["item"], "counter", array()) == "True")) {
                // line 13
                echo "            <br>
        ";
            }
            // line 14
            echo "    
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "    </ul>
</p>
";
        
        $__internal_f3cfc25e00b8314b6a6acf5a7a0969454aaec1e2abf6681497399b3acdcc766e->leave($__internal_f3cfc25e00b8314b6a6acf5a7a0969454aaec1e2abf6681497399b3acdcc766e_prof);

    }

    public function getTemplateName()
    {
        return "NTPBundle:File:files_history.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 16,  71 => 14,  67 => 13,  64 => 12,  57 => 9,  51 => 7,  48 => 6,  44 => 5,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <p class="text-center">*/
/*     <ul class="list-inline">*/
/*     {% for item in dateArray %}*/
/*         {% if item.inarray == "True" %}*/
/*            <li><span class="label label-success">{{ item.date|date('d-m-Y D') }} </span></li>*/
/*         {% else %}*/
/*            <li><span class="label label-danger">{{ item.date|date('d-m-Y D') }}</span></li>*/
/* */
/*         {% endif %}*/
/*         {% if item.counter == "True" %}*/
/*             <br>*/
/*         {% endif %}    */
/*     {% endfor %}*/
/*     </ul>*/
/* </p>*/
/* {% endblock %}*/
/* */
