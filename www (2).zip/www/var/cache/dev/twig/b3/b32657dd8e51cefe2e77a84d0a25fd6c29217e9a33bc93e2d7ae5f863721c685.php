<?php

/* knp_menu_base.html.twig */
class __TwigTemplate_655eaa2aa681411c4261891239fb807ce16a2134c3022e4771d27e16f6e73ce1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eac6feb9988dc5c54f8be1767a7044cad4414d3824335e95ea15391344f62d7a = $this->env->getExtension("native_profiler");
        $__internal_eac6feb9988dc5c54f8be1767a7044cad4414d3824335e95ea15391344f62d7a->enter($__internal_eac6feb9988dc5c54f8be1767a7044cad4414d3824335e95ea15391344f62d7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "knp_menu_base.html.twig"));

        // line 1
        if ($this->getAttribute((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")), "compressed", array())) {
            $this->displayBlock("compressed_root", $context, $blocks);
        } else {
            $this->displayBlock("root", $context, $blocks);
        }
        
        $__internal_eac6feb9988dc5c54f8be1767a7044cad4414d3824335e95ea15391344f62d7a->leave($__internal_eac6feb9988dc5c54f8be1767a7044cad4414d3824335e95ea15391344f62d7a_prof);

    }

    public function getTemplateName()
    {
        return "knp_menu_base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% if options.compressed %}{{ block('compressed_root') }}{% else %}{{ block('root') }}{% endif %}*/
/* */
