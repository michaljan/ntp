<?php

namespace NTPBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NTPBundle extends Bundle
{
}
