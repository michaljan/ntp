<?php

// WebProfilerBundle:Profiler:toolbar_js.html.twig
return array (
);
