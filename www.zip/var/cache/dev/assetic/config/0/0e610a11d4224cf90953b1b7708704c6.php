<?php

// NTPBundle:File:file_processed.html.twig
return array (
  '999aeda' => 
  array (
    0 => 
    array (
      0 => '@NTPBundle/Resources/public/js/*',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/999aeda.js',
      'name' => '999aeda',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '1f10d61' => 
  array (
    0 => 
    array (
      0 => 'bundles/ntp/css/*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/1f10d61.css',
      'name' => '1f10d61',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
