<?php

// FOSUserBundle:Resetting:email.txt.twig
return array (
);
