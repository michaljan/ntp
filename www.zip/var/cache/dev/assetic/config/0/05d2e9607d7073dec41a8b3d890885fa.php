<?php

// WebProfilerBundle:Collector:events.html.twig
return array (
);
