<?php

// FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig
return array (
);
