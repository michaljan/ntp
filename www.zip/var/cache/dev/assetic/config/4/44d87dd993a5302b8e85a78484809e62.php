<?php

// WebProfilerBundle:Router:panel.html.twig
return array (
);
