<?php

// WebProfilerBundle:Profiler:toolbar_redirect.html.twig
return array (
);
