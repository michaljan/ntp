<?php

// FOSUserBundle::layout.html.twig
return array (
);
