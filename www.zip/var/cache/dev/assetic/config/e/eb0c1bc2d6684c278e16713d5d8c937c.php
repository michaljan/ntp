<?php

// FOSUserBundle:Resetting:reset.html.twig
return array (
);
