<?php

// TwigBundle:Exception:error.js.twig
return array (
);
