<?php

// WebProfilerBundle:Profiler:profiler.css.twig
return array (
);
