<?php

// WebProfilerBundle:Profiler:search.html.twig
return array (
);
