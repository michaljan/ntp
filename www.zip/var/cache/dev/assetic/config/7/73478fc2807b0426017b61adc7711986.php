<?php

// FOSUserBundle:Registration:register.html.twig
return array (
);
