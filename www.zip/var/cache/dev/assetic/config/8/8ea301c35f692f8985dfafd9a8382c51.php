<?php

// FOSUserBundle:Resetting:request_content.html.twig
return array (
);
