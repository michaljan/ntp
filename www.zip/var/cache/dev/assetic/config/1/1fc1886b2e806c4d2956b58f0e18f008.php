<?php

// FOSUserBundle:Resetting:reset_content.html.twig
return array (
);
