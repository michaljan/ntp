<?php

// WebProfilerBundle:Collector:ajax.html.twig
return array (
);
