<?php

/* @Twig/Exception/error.txt.twig */
class __TwigTemplate_41d479c8e2aa4d64a857e3c27fd02ceb52d242a2e5b06b0bf3afa9cd106966c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d255276328b905fcaebfc44ed19e0c72e13c9c155caf79176598e2a7c615aa72 = $this->env->getExtension("native_profiler");
        $__internal_d255276328b905fcaebfc44ed19e0c72e13c9c155caf79176598e2a7c615aa72->enter($__internal_d255276328b905fcaebfc44ed19e0c72e13c9c155caf79176598e2a7c615aa72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_d255276328b905fcaebfc44ed19e0c72e13c9c155caf79176598e2a7c615aa72->leave($__internal_d255276328b905fcaebfc44ed19e0c72e13c9c155caf79176598e2a7c615aa72_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 4,  22 => 1,);
    }
}
/* Oops! An Error Occurred*/
/* =======================*/
/* */
/* The server returned a "{{ status_code }} {{ status_text }}".*/
/* */
/* Something is broken. Please let us know what you were doing when this error occurred.*/
/* We will fix it as soon as possible. Sorry for any inconvenience caused.*/
/* */
