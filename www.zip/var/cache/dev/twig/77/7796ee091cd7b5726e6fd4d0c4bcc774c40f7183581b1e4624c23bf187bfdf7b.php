<?php

/* @FOSUser/Group/show_content.html.twig */
class __TwigTemplate_090d185c6443fce70551b2a2fc915c80c3bc37775a763cfb7864157c0932bbda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_adfc765c93dd60da738f3e964097cc58fb4fe553ea5925c06985605773673829 = $this->env->getExtension("native_profiler");
        $__internal_adfc765c93dd60da738f3e964097cc58fb4fe553ea5925c06985605773673829->enter($__internal_adfc765c93dd60da738f3e964097cc58fb4fe553ea5925c06985605773673829_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/show_content.html.twig"));

        // line 2
        echo "
<div class=\"fos_user_group_show\">
    <p>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("group.show.name", array(), "FOSUserBundle"), "html", null, true);
        echo ": ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "getName", array(), "method"), "html", null, true);
        echo "</p>
</div>
";
        
        $__internal_adfc765c93dd60da738f3e964097cc58fb4fe553ea5925c06985605773673829->leave($__internal_adfc765c93dd60da738f3e964097cc58fb4fe553ea5925c06985605773673829_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/show_content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 4,  22 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* <div class="fos_user_group_show">*/
/*     <p>{{ 'group.show.name'|trans }}: {{ group.getName() }}</p>*/
/* </div>*/
/* */
