<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_fed3a555c91183975ca28a7ccae7f786131169de36530a99062cba0600673e2e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e7521fce49c53ffdefb45041deaef8db11e34c19ef782254f4fe3c8095fb1aa7 = $this->env->getExtension("native_profiler");
        $__internal_e7521fce49c53ffdefb45041deaef8db11e34c19ef782254f4fe3c8095fb1aa7->enter($__internal_e7521fce49c53ffdefb45041deaef8db11e34c19ef782254f4fe3c8095fb1aa7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_e7521fce49c53ffdefb45041deaef8db11e34c19ef782254f4fe3c8095fb1aa7->leave($__internal_e7521fce49c53ffdefb45041deaef8db11e34c19ef782254f4fe3c8095fb1aa7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
