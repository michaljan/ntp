<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_3154a86cdc05375ba64e6f2c960220895b14d953f20add034c3e57db07f77e90 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b52db3c052ea853edb1576b1260bbcea377b844a7c343d5599c7df8a81a857b0 = $this->env->getExtension("native_profiler");
        $__internal_b52db3c052ea853edb1576b1260bbcea377b844a7c343d5599c7df8a81a857b0->enter($__internal_b52db3c052ea853edb1576b1260bbcea377b844a7c343d5599c7df8a81a857b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_b52db3c052ea853edb1576b1260bbcea377b844a7c343d5599c7df8a81a857b0->leave($__internal_b52db3c052ea853edb1576b1260bbcea377b844a7c343d5599c7df8a81a857b0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
