<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_cd69e94fa1a43e81d82f169fed10961e9d869ffad1a13ffc126dd497ec6cba7f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4fd081cb91966097ab572c65bc73e890851109caf695d28c09571478982471fb = $this->env->getExtension("native_profiler");
        $__internal_4fd081cb91966097ab572c65bc73e890851109caf695d28c09571478982471fb->enter($__internal_4fd081cb91966097ab572c65bc73e890851109caf695d28c09571478982471fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_4fd081cb91966097ab572c65bc73e890851109caf695d28c09571478982471fb->leave($__internal_4fd081cb91966097ab572c65bc73e890851109caf695d28c09571478982471fb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
