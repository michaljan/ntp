<?php

/* FOSUserBundle:Registration:checkEmail.html.twig */
class __TwigTemplate_7155ab549fab3411295af05671354a3cc77cb235d67a6a06065a1b938fde8b2f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f66ebc85d2f70afd2427596d6ec5c5c32a8af73f2bab269d7348315eda0fe00c = $this->env->getExtension("native_profiler");
        $__internal_f66ebc85d2f70afd2427596d6ec5c5c32a8af73f2bab269d7348315eda0fe00c->enter($__internal_f66ebc85d2f70afd2427596d6ec5c5c32a8af73f2bab269d7348315eda0fe00c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f66ebc85d2f70afd2427596d6ec5c5c32a8af73f2bab269d7348315eda0fe00c->leave($__internal_f66ebc85d2f70afd2427596d6ec5c5c32a8af73f2bab269d7348315eda0fe00c_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a8bb4f30aeca27b9960448cc802f3bd9ea9aa048bad8c1ee9eeb0fde9f032f7f = $this->env->getExtension("native_profiler");
        $__internal_a8bb4f30aeca27b9960448cc802f3bd9ea9aa048bad8c1ee9eeb0fde9f032f7f->enter($__internal_a8bb4f30aeca27b9960448cc802f3bd9ea9aa048bad8c1ee9eeb0fde9f032f7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "    <p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("registration.check_email", array("%email%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array())), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_a8bb4f30aeca27b9960448cc802f3bd9ea9aa048bad8c1ee9eeb0fde9f032f7f->leave($__internal_a8bb4f30aeca27b9960448cc802f3bd9ea9aa048bad8c1ee9eeb0fde9f032f7f_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/*     <p>{{ 'registration.check_email'|trans({'%email%': user.email}) }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
