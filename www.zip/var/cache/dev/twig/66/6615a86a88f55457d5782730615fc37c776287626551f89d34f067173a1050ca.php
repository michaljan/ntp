<?php

/* NTPBundle:File:files_display.html.twig */
class __TwigTemplate_36fab752656068d2f4b432b50d0b55f5840e7e38f2d098de978e18a437a06d2d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "NTPBundle:File:files_display.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_43f2797611aebe6a83d912a1dadc8b084a3bb88c59473b3e3839c52e106125c7 = $this->env->getExtension("native_profiler");
        $__internal_43f2797611aebe6a83d912a1dadc8b084a3bb88c59473b3e3839c52e106125c7->enter($__internal_43f2797611aebe6a83d912a1dadc8b084a3bb88c59473b3e3839c52e106125c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NTPBundle:File:files_display.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_43f2797611aebe6a83d912a1dadc8b084a3bb88c59473b3e3839c52e106125c7->leave($__internal_43f2797611aebe6a83d912a1dadc8b084a3bb88c59473b3e3839c52e106125c7_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_26d7f4c56e8c24d9d420f99fb8cf1cf5e2c2a1c7599ff7e48fabce4855eb135b = $this->env->getExtension("native_profiler");
        $__internal_26d7f4c56e8c24d9d420f99fb8cf1cf5e2c2a1c7599ff7e48fabce4855eb135b->enter($__internal_26d7f4c56e8c24d9d420f99fb8cf1cf5e2c2a1c7599ff7e48fabce4855eb135b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <table class=\"table table-striped\">

        <thead>
            <tr>
                <th>#</th>
                <th>Plan name</th>
                <th>File name</th>
                <th>Plan date</th>
                <th>Uploaded date</th>
                <th>Action</th>
            </tr>
        </thead>
        ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["fileProcessed"]) ? $context["fileProcessed"] : $this->getContext($context, "fileProcessed")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 16
            echo "            <tr>
                <td>";
            // line 17
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getId", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getName", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "getPath", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "getPlanDate", array()), "d-m-Y"), "html", null, true);
            echo "</td>
                <td>";
            // line 21
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["item"], "getUploadedAt", array()), "d-m-Y H:i"), "html", null, true);
            echo "</td>
                <td>
                    <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("process_csv", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-success\">Process</a>
                    <a href=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("delete_csv", array("id" => $this->getAttribute($context["item"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a>
                </td>

            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "
    </table>
";
        
        $__internal_26d7f4c56e8c24d9d420f99fb8cf1cf5e2c2a1c7599ff7e48fabce4855eb135b->leave($__internal_26d7f4c56e8c24d9d420f99fb8cf1cf5e2c2a1c7599ff7e48fabce4855eb135b_prof);

    }

    public function getTemplateName()
    {
        return "NTPBundle:File:files_display.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  97 => 29,  86 => 24,  82 => 23,  77 => 21,  73 => 20,  69 => 19,  65 => 18,  61 => 17,  58 => 16,  54 => 15,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <table class="table table-striped">*/
/* */
/*         <thead>*/
/*             <tr>*/
/*                 <th>#</th>*/
/*                 <th>Plan name</th>*/
/*                 <th>File name</th>*/
/*                 <th>Plan date</th>*/
/*                 <th>Uploaded date</th>*/
/*                 <th>Action</th>*/
/*             </tr>*/
/*         </thead>*/
/*         {% for item in fileProcessed %}*/
/*             <tr>*/
/*                 <td>{{ item.getId }}</td>*/
/*                 <td>{{ item.getName }}</td>*/
/*                 <td>{{ item.getPath }}</td>*/
/*                 <td>{{ item.getPlanDate|date('d-m-Y') }}</td>*/
/*                 <td>{{ item.getUploadedAt|date('d-m-Y H:i') }}</td>*/
/*                 <td>*/
/*                     <a href="{{ path('process_csv',{ id: item.id }) }}" class="btn btn-success">Process</a>*/
/*                     <a href="{{ path('delete_csv',{ id: item.id }) }}" class="btn btn-danger">Delete</a>*/
/*                 </td>*/
/* */
/*             </tr>*/
/*         {% endfor %}*/
/* */
/*     </table>*/
/* {% endblock %}*/
/* */
