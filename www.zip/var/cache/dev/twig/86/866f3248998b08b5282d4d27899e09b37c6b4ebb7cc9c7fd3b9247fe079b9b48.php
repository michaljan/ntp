<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_bf8d2050a73eaed63953b18f8801428be6ad2d9d59cee4a8383e30b0e024ea18 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4d8d98aaf3e4eeb57221221416e9e46837fe93c4befdcf9a208b3f3def8b7709 = $this->env->getExtension("native_profiler");
        $__internal_4d8d98aaf3e4eeb57221221416e9e46837fe93c4befdcf9a208b3f3def8b7709->enter($__internal_4d8d98aaf3e4eeb57221221416e9e46837fe93c4befdcf9a208b3f3def8b7709_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_4d8d98aaf3e4eeb57221221416e9e46837fe93c4befdcf9a208b3f3def8b7709->leave($__internal_4d8d98aaf3e4eeb57221221416e9e46837fe93c4befdcf9a208b3f3def8b7709_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo str_replace('{{ widget }}', $view['form']->block($form, 'form_widget_simple'), $money_pattern) ?>*/
/* */
