<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_f711b6507583b18e98f2942fb29c13203e3d8cde615f5baf4566a285939a43bb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d7442c0a8361eb49996e27e379876592419d4a1556f8a8575c4198eaf84ae6d1 = $this->env->getExtension("native_profiler");
        $__internal_d7442c0a8361eb49996e27e379876592419d4a1556f8a8575c4198eaf84ae6d1->enter($__internal_d7442c0a8361eb49996e27e379876592419d4a1556f8a8575c4198eaf84ae6d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_d7442c0a8361eb49996e27e379876592419d4a1556f8a8575c4198eaf84ae6d1->leave($__internal_d7442c0a8361eb49996e27e379876592419d4a1556f8a8575c4198eaf84ae6d1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
