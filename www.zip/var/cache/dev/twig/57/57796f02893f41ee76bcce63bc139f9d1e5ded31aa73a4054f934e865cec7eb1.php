<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_4c3322b760ae4fbb593e69b5a238160202d8270eceed16259eac98372fc30d42 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_31e3e8b116c671d0df5ed03ddd297b005f0f75d6b353332236949c8dcdd98bd2 = $this->env->getExtension("native_profiler");
        $__internal_31e3e8b116c671d0df5ed03ddd297b005f0f75d6b353332236949c8dcdd98bd2->enter($__internal_31e3e8b116c671d0df5ed03ddd297b005f0f75d6b353332236949c8dcdd98bd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_31e3e8b116c671d0df5ed03ddd297b005f0f75d6b353332236949c8dcdd98bd2->leave($__internal_31e3e8b116c671d0df5ed03ddd297b005f0f75d6b353332236949c8dcdd98bd2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
