<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_dfa01f309e6a9f2fde83d26787785ee77892ab00d8d107f40fdb9abe5a365d33 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_29965200e9e745081cc197d5d79c34b5222f3fc5a0d194824774edfa65fbda72 = $this->env->getExtension("native_profiler");
        $__internal_29965200e9e745081cc197d5d79c34b5222f3fc5a0d194824774edfa65fbda72->enter($__internal_29965200e9e745081cc197d5d79c34b5222f3fc5a0d194824774edfa65fbda72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_29965200e9e745081cc197d5d79c34b5222f3fc5a0d194824774edfa65fbda72->leave($__internal_29965200e9e745081cc197d5d79c34b5222f3fc5a0d194824774edfa65fbda72_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
