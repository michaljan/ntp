<?php

/* @NTP/Default/index.html.twig */
class __TwigTemplate_8c9be58d25c08443dcce4287a1be23c8bda97276665c0459c7241e220e485df2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "@NTP/Default/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84cccb9bd8953b75eb59bc004ded8ce56408d494fce30107ceb5f694797b966b = $this->env->getExtension("native_profiler");
        $__internal_84cccb9bd8953b75eb59bc004ded8ce56408d494fce30107ceb5f694797b966b->enter($__internal_84cccb9bd8953b75eb59bc004ded8ce56408d494fce30107ceb5f694797b966b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@NTP/Default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_84cccb9bd8953b75eb59bc004ded8ce56408d494fce30107ceb5f694797b966b->leave($__internal_84cccb9bd8953b75eb59bc004ded8ce56408d494fce30107ceb5f694797b966b_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_d66994b8059ac1a6e033eaf89045e94d46b31017ac27c822a1e194b845803b1d = $this->env->getExtension("native_profiler");
        $__internal_d66994b8059ac1a6e033eaf89045e94d46b31017ac27c822a1e194b845803b1d->enter($__internal_d66994b8059ac1a6e033eaf89045e94d46b31017ac27c822a1e194b845803b1d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <p>Hello Twig</p>
";
        
        $__internal_d66994b8059ac1a6e033eaf89045e94d46b31017ac27c822a1e194b845803b1d->leave($__internal_d66994b8059ac1a6e033eaf89045e94d46b31017ac27c822a1e194b845803b1d_prof);

    }

    public function getTemplateName()
    {
        return "@NTP/Default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <p>Hello Twig</p>*/
/* {% endblock %}*/
/* */
