<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_238a07855bea01c2d4511d31f79f589dffa5fd3d3e12aa697d92f20f2ceb4db3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f64fe181f4adfdb4cdb96263bdff36587289e71c83f04181af00ac99acf3227 = $this->env->getExtension("native_profiler");
        $__internal_9f64fe181f4adfdb4cdb96263bdff36587289e71c83f04181af00ac99acf3227->enter($__internal_9f64fe181f4adfdb4cdb96263bdff36587289e71c83f04181af00ac99acf3227_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_9f64fe181f4adfdb4cdb96263bdff36587289e71c83f04181af00ac99acf3227->leave($__internal_9f64fe181f4adfdb4cdb96263bdff36587289e71c83f04181af00ac99acf3227_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}*/
/* */
