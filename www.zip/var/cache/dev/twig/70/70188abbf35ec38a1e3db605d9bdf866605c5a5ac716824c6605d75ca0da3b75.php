<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_69984b5d797f5606e7648efe66a2e6938269133d8a4d77b0b1e8280e5921ca77 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06e12b3dd87db560f6a233669374fda9e06a3a2efa1f34c3301d457ecd78c8e5 = $this->env->getExtension("native_profiler");
        $__internal_06e12b3dd87db560f6a233669374fda9e06a3a2efa1f34c3301d457ecd78c8e5->enter($__internal_06e12b3dd87db560f6a233669374fda9e06a3a2efa1f34c3301d457ecd78c8e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_06e12b3dd87db560f6a233669374fda9e06a3a2efa1f34c3301d457ecd78c8e5->leave($__internal_06e12b3dd87db560f6a233669374fda9e06a3a2efa1f34c3301d457ecd78c8e5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!$label) { $label = isset($label_format)*/
/*     ? strtr($label_format, array('%name%' => $name, '%id%' => $id))*/
/*     : $view['form']->humanize($name); } ?>*/
/* <button type="<?php echo isset($type) ? $view->escape($type) : 'button' ?>" <?php echo $view['form']->block($form, 'button_attributes') ?>><?php echo $view->escape(false !== $translation_domain ? $view['translator']->trans($label, array(), $translation_domain) : $label) ?></button>*/
/* */
