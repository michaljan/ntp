<?php

/* @FOSUser/Group/list.html.twig */
class __TwigTemplate_c3b502c2f05dee964c78779a3e010a0c1e0798b2cb9140c2caab2ecb0a3442fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Group/list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b1b9dfc6964b4643d5f5c860ddedc3ab9420aaebc9e6d7341313d62928d142a = $this->env->getExtension("native_profiler");
        $__internal_9b1b9dfc6964b4643d5f5c860ddedc3ab9420aaebc9e6d7341313d62928d142a->enter($__internal_9b1b9dfc6964b4643d5f5c860ddedc3ab9420aaebc9e6d7341313d62928d142a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9b1b9dfc6964b4643d5f5c860ddedc3ab9420aaebc9e6d7341313d62928d142a->leave($__internal_9b1b9dfc6964b4643d5f5c860ddedc3ab9420aaebc9e6d7341313d62928d142a_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a8a9544e6317df9250b4766dd6026eb08d0e72832618a6f736087d71eac035f7 = $this->env->getExtension("native_profiler");
        $__internal_a8a9544e6317df9250b4766dd6026eb08d0e72832618a6f736087d71eac035f7->enter($__internal_a8a9544e6317df9250b4766dd6026eb08d0e72832618a6f736087d71eac035f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "@FOSUser/Group/list.html.twig", 4)->display($context);
        
        $__internal_a8a9544e6317df9250b4766dd6026eb08d0e72832618a6f736087d71eac035f7->leave($__internal_a8a9544e6317df9250b4766dd6026eb08d0e72832618a6f736087d71eac035f7_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:list_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
