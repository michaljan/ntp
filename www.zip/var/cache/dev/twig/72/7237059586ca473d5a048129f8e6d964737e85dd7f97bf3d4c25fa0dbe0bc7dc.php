<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_e98866b72b4014a6f2623904a8361c0377f06867b4f08e62791370101b72e2ac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_467b39ad9b89aac571edf8dcce2de2878776e31447cc3fc5e03936d73f44b576 = $this->env->getExtension("native_profiler");
        $__internal_467b39ad9b89aac571edf8dcce2de2878776e31447cc3fc5e03936d73f44b576->enter($__internal_467b39ad9b89aac571edf8dcce2de2878776e31447cc3fc5e03936d73f44b576_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_467b39ad9b89aac571edf8dcce2de2878776e31447cc3fc5e03936d73f44b576->leave($__internal_467b39ad9b89aac571edf8dcce2de2878776e31447cc3fc5e03936d73f44b576_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */
