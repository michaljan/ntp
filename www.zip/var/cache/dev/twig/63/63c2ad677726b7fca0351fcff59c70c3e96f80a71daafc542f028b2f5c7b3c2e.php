<?php

/* FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig */
class __TwigTemplate_9343de0b106c8018330d6978f2abf29f837446e48b5a058ed4b9334301551b27 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c3d5434ba3c5191b43a5217b344f751220b5d49e2427fc67afc8f5a9820e4639 = $this->env->getExtension("native_profiler");
        $__internal_c3d5434ba3c5191b43a5217b344f751220b5d49e2427fc67afc8f5a9820e4639->enter($__internal_c3d5434ba3c5191b43a5217b344f751220b5d49e2427fc67afc8f5a9820e4639_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c3d5434ba3c5191b43a5217b344f751220b5d49e2427fc67afc8f5a9820e4639->leave($__internal_c3d5434ba3c5191b43a5217b344f751220b5d49e2427fc67afc8f5a9820e4639_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_09fe9752e48f1d944282429e34467b83982d04c979443c76eb833bde6b732a21 = $this->env->getExtension("native_profiler");
        $__internal_09fe9752e48f1d944282429e34467b83982d04c979443c76eb833bde6b732a21->enter($__internal_09fe9752e48f1d944282429e34467b83982d04c979443c76eb833bde6b732a21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_09fe9752e48f1d944282429e34467b83982d04c979443c76eb833bde6b732a21->leave($__internal_09fe9752e48f1d944282429e34467b83982d04c979443c76eb833bde6b732a21_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>{{ 'resetting.password_already_requested'|trans }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
