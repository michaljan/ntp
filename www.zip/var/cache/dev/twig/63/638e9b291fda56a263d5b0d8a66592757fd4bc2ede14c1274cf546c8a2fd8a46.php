<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_8fa94772a0c687402ed25866abf8676426069dea7378be48c0c0651b2f91650e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_997b7cfedaa412118df4d413c56a39cff2a1369db09f0d5776b705e4cfaeb2ab = $this->env->getExtension("native_profiler");
        $__internal_997b7cfedaa412118df4d413c56a39cff2a1369db09f0d5776b705e4cfaeb2ab->enter($__internal_997b7cfedaa412118df4d413c56a39cff2a1369db09f0d5776b705e4cfaeb2ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_997b7cfedaa412118df4d413c56a39cff2a1369db09f0d5776b705e4cfaeb2ab->leave($__internal_997b7cfedaa412118df4d413c56a39cff2a1369db09f0d5776b705e4cfaeb2ab_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
