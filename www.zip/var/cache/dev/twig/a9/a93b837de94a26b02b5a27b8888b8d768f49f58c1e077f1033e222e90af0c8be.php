<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_02abb50a75ed26e2b79f495fba8a08b68f745100cad60fbc4e507824ff9fff12 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8cee1f871812e7260aaba6aa64b744fdc6cdbbb6049595617df5c91c72645827 = $this->env->getExtension("native_profiler");
        $__internal_8cee1f871812e7260aaba6aa64b744fdc6cdbbb6049595617df5c91c72645827->enter($__internal_8cee1f871812e7260aaba6aa64b744fdc6cdbbb6049595617df5c91c72645827_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_8cee1f871812e7260aaba6aa64b744fdc6cdbbb6049595617df5c91c72645827->leave($__internal_8cee1f871812e7260aaba6aa64b744fdc6cdbbb6049595617df5c91c72645827_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
