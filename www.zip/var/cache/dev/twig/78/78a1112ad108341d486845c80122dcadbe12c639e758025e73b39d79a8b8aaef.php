<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_7287dc327734ee9316cc79374fecf68702ca3268fe4e76142880bbcba4a4c2f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e49d01e5f556c0fcbc3715cc2ac0b3f3146fabbf9c57f8f5188631ec3522afe9 = $this->env->getExtension("native_profiler");
        $__internal_e49d01e5f556c0fcbc3715cc2ac0b3f3146fabbf9c57f8f5188631ec3522afe9->enter($__internal_e49d01e5f556c0fcbc3715cc2ac0b3f3146fabbf9c57f8f5188631ec3522afe9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_e49d01e5f556c0fcbc3715cc2ac0b3f3146fabbf9c57f8f5188631ec3522afe9->leave($__internal_e49d01e5f556c0fcbc3715cc2ac0b3f3146fabbf9c57f8f5188631ec3522afe9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
