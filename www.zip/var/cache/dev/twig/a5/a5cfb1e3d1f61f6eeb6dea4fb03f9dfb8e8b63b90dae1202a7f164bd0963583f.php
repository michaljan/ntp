<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_bd1e27fc68ae66f67e2797a96d03ccaac07330b49e32188cef79c3a7c72787b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6148bc876d7e21fcb31a5b7b1063e9cee589c8f8825c5c1f1a5a26d23f44a070 = $this->env->getExtension("native_profiler");
        $__internal_6148bc876d7e21fcb31a5b7b1063e9cee589c8f8825c5c1f1a5a26d23f44a070->enter($__internal_6148bc876d7e21fcb31a5b7b1063e9cee589c8f8825c5c1f1a5a26d23f44a070_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_6148bc876d7e21fcb31a5b7b1063e9cee589c8f8825c5c1f1a5a26d23f44a070->leave($__internal_6148bc876d7e21fcb31a5b7b1063e9cee589c8f8825c5c1f1a5a26d23f44a070_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
