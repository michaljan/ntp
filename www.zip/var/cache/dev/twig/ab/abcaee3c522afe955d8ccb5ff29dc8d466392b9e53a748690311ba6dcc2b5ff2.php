<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_e4fa21143713278a1638a0f93d5d34de958ae081004c7ecea87a9af415488380 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2638b2c44adc20a6e2f300cd054141a82ea1dda65894dac6b2c4560eb72d7a94 = $this->env->getExtension("native_profiler");
        $__internal_2638b2c44adc20a6e2f300cd054141a82ea1dda65894dac6b2c4560eb72d7a94->enter($__internal_2638b2c44adc20a6e2f300cd054141a82ea1dda65894dac6b2c4560eb72d7a94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_2638b2c44adc20a6e2f300cd054141a82ea1dda65894dac6b2c4560eb72d7a94->leave($__internal_2638b2c44adc20a6e2f300cd054141a82ea1dda65894dac6b2c4560eb72d7a94_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_0a59e5728fa51c8503077673b85b14e938be7aa8304f4668e5a7160100a0d6b8 = $this->env->getExtension("native_profiler");
        $__internal_0a59e5728fa51c8503077673b85b14e938be7aa8304f4668e5a7160100a0d6b8->enter($__internal_0a59e5728fa51c8503077673b85b14e938be7aa8304f4668e5a7160100a0d6b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_0a59e5728fa51c8503077673b85b14e938be7aa8304f4668e5a7160100a0d6b8->leave($__internal_0a59e5728fa51c8503077673b85b14e938be7aa8304f4668e5a7160100a0d6b8_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_420ca99c217a137022aebfff7d538953c6467f01ff72cb17fdb3cbfde0c6ac3b = $this->env->getExtension("native_profiler");
        $__internal_420ca99c217a137022aebfff7d538953c6467f01ff72cb17fdb3cbfde0c6ac3b->enter($__internal_420ca99c217a137022aebfff7d538953c6467f01ff72cb17fdb3cbfde0c6ac3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_420ca99c217a137022aebfff7d538953c6467f01ff72cb17fdb3cbfde0c6ac3b->leave($__internal_420ca99c217a137022aebfff7d538953c6467f01ff72cb17fdb3cbfde0c6ac3b_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_1bbdbae047b71f5c6175bdd42e906a725cfa767c7bdac3473992588f4c9a3cd3 = $this->env->getExtension("native_profiler");
        $__internal_1bbdbae047b71f5c6175bdd42e906a725cfa767c7bdac3473992588f4c9a3cd3->enter($__internal_1bbdbae047b71f5c6175bdd42e906a725cfa767c7bdac3473992588f4c9a3cd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_1bbdbae047b71f5c6175bdd42e906a725cfa767c7bdac3473992588f4c9a3cd3->leave($__internal_1bbdbae047b71f5c6175bdd42e906a725cfa767c7bdac3473992588f4c9a3cd3_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
