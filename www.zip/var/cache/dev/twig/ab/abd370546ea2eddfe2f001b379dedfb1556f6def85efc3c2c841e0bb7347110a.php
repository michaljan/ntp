<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_45ca5643cd360ecf34afdda968a2d13c4a55b6453d1649d20afa1e700614c2cc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_051777155778db4cce7176f8b049e3f01f8ba073261843f24f652e69cf8bad9c = $this->env->getExtension("native_profiler");
        $__internal_051777155778db4cce7176f8b049e3f01f8ba073261843f24f652e69cf8bad9c->enter($__internal_051777155778db4cce7176f8b049e3f01f8ba073261843f24f652e69cf8bad9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_051777155778db4cce7176f8b049e3f01f8ba073261843f24f652e69cf8bad9c->leave($__internal_051777155778db4cce7176f8b049e3f01f8ba073261843f24f652e69cf8bad9c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
