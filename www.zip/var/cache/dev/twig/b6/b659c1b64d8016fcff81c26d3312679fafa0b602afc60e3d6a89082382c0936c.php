<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_136043d970fde3c6e8a967cf7f5991deff7a5f6414656a35e815f5a36aa2534e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d33b80bd383874b868b046fddae7eed2945eccaa286e85a72ccad0d38c15c026 = $this->env->getExtension("native_profiler");
        $__internal_d33b80bd383874b868b046fddae7eed2945eccaa286e85a72ccad0d38c15c026->enter($__internal_d33b80bd383874b868b046fddae7eed2945eccaa286e85a72ccad0d38c15c026_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_d33b80bd383874b868b046fddae7eed2945eccaa286e85a72ccad0d38c15c026->leave($__internal_d33b80bd383874b868b046fddae7eed2945eccaa286e85a72ccad0d38c15c026_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
