<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_db61e9595cf1e5ebd9f171eafea4df8ef741be2c2e44074829ce8b337b6cee32 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_60e565bd3c398a246e264ad7843d105433564e1ae3912b77c6e300634e23c336 = $this->env->getExtension("native_profiler");
        $__internal_60e565bd3c398a246e264ad7843d105433564e1ae3912b77c6e300634e23c336->enter($__internal_60e565bd3c398a246e264ad7843d105433564e1ae3912b77c6e300634e23c336_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_60e565bd3c398a246e264ad7843d105433564e1ae3912b77c6e300634e23c336->leave($__internal_60e565bd3c398a246e264ad7843d105433564e1ae3912b77c6e300634e23c336_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <table <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <tr>*/
/*         <td colspan="2">*/
/*             <?php echo $view['form']->errors($form) ?>*/
/*         </td>*/
/*     </tr>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </table>*/
/* */
