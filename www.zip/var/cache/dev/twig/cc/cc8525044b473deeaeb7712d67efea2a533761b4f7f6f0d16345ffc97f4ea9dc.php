<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_f8cb78430ceea7adc5f57756c89afafe6c7914286132e63a3a67d77b911d3603 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8be63872ec5a3c507f9651d501bd1f717d5acc60092ff626eac5bbdd03d6f370 = $this->env->getExtension("native_profiler");
        $__internal_8be63872ec5a3c507f9651d501bd1f717d5acc60092ff626eac5bbdd03d6f370->enter($__internal_8be63872ec5a3c507f9651d501bd1f717d5acc60092ff626eac5bbdd03d6f370_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_8be63872ec5a3c507f9651d501bd1f717d5acc60092ff626eac5bbdd03d6f370->leave($__internal_8be63872ec5a3c507f9651d501bd1f717d5acc60092ff626eac5bbdd03d6f370_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
