<?php

/* NTPBundle:Reports:paragonRunSheetReport.html.twig */
class __TwigTemplate_a306646aa76f2fb8f283ef2f4d11143e0fd7c7086fad6ece78d16f92d3260abc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "NTPBundle:Reports:paragonRunSheetReport.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'documentReady' => array($this, 'block_documentReady'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e02028e6ce59121d92c90968b00d64f7dc3d01cda8f6e099a690a9df9bf0191d = $this->env->getExtension("native_profiler");
        $__internal_e02028e6ce59121d92c90968b00d64f7dc3d01cda8f6e099a690a9df9bf0191d->enter($__internal_e02028e6ce59121d92c90968b00d64f7dc3d01cda8f6e099a690a9df9bf0191d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NTPBundle:Reports:paragonRunSheetReport.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e02028e6ce59121d92c90968b00d64f7dc3d01cda8f6e099a690a9df9bf0191d->leave($__internal_e02028e6ce59121d92c90968b00d64f7dc3d01cda8f6e099a690a9df9bf0191d_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_285c46ee12809bfe31508feee07d9b3c16071d1a343377b6c5200202763ada4b = $this->env->getExtension("native_profiler");
        $__internal_285c46ee12809bfe31508feee07d9b3c16071d1a343377b6c5200202763ada4b->enter($__internal_285c46ee12809bfe31508feee07d9b3c16071d1a343377b6c5200202763ada4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    ";
        if ((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report"))) {
            echo "            
        <br/>
        <div class=\"row\">
            <div class=\"col-md-4\">
                <div class=\"row\">
                    <div class=\"col-md-5\">
                        ";
            // line 9
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("id" => "form_person_edit")));
            echo "
                        ";
            // line 10
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
                        ";
            // line 11
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "planDate", array()), 'row');
            echo "
                        ";
            // line 12
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
            echo "
                        ";
            // line 13
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
            echo "</div>
                    <div class=\"col-md-7\">
                    </div>
                </div>
            </div>
        </div>
    ";
        } else {
            // line 20
            echo "        <div class=\"row\">
            <div class=\"col-md-3\">
                ";
            // line 22
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("id" => "form1")));
            echo "
                ";
            // line 23
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
                ";
            // line 24
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "planDate", array()), 'row');
            echo "
                ";
            // line 25
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
            echo "
                ";
            // line 26
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
            echo "</div>
            <br/>
        </div>
    ";
        }
        
        $__internal_285c46ee12809bfe31508feee07d9b3c16071d1a343377b6c5200202763ada4b->leave($__internal_285c46ee12809bfe31508feee07d9b3c16071d1a343377b6c5200202763ada4b_prof);

    }

    // line 31
    public function block_documentReady($context, array $blocks = array())
    {
        $__internal_23f4f939100998ff88658bb340c3ac157f356b7fbea702a67d56f04727db1220 = $this->env->getExtension("native_profiler");
        $__internal_23f4f939100998ff88658bb340c3ac157f356b7fbea702a67d56f04727db1220->enter($__internal_23f4f939100998ff88658bb340c3ac157f356b7fbea702a67d56f04727db1220_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "documentReady"));

        // line 32
        echo "    \$('#form1').submit(function(event){
    var data=\"\";
    \$.ajax({
            type: \"POST\",
            url: \"";
        // line 36
        echo $this->env->getExtension('routing')->getPath("paragon_run_sheets_report");
        echo "\",
            data: data,
            dataType: \"json\",
            success: function(response)
            {   
                alert('Good');
            },

            error: function(XMLHttpRequest, textStatus, errorThrown)
            {
                alert('Error : ' + errorThrown);
            },
            });
         
}
)

";
        
        $__internal_23f4f939100998ff88658bb340c3ac157f356b7fbea702a67d56f04727db1220->leave($__internal_23f4f939100998ff88658bb340c3ac157f356b7fbea702a67d56f04727db1220_prof);

    }

    public function getTemplateName()
    {
        return "NTPBundle:Reports:paragonRunSheetReport.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 36,  115 => 32,  109 => 31,  97 => 26,  93 => 25,  89 => 24,  85 => 23,  81 => 22,  77 => 20,  67 => 13,  63 => 12,  59 => 11,  55 => 10,  51 => 9,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     {% if report %}            */
/*         <br/>*/
/*         <div class="row">*/
/*             <div class="col-md-4">*/
/*                 <div class="row">*/
/*                     <div class="col-md-5">*/
/*                         {{ form_start(form,{'attr': {'id': 'form_person_edit'}}) }}*/
/*                         {{ form_errors(form) }}*/
/*                         {{ form_row(form.planDate) }}*/
/*                         {{ form_row(form.submit) }}*/
/*                         {{ form_end(form) }}</div>*/
/*                     <div class="col-md-7">*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     {% else %}*/
/*         <div class="row">*/
/*             <div class="col-md-3">*/
/*                 {{ form_start(form,{'attr': {'id': 'form1'}}) }}*/
/*                 {{ form_errors(form) }}*/
/*                 {{ form_row(form.planDate) }}*/
/*                 {{ form_row(form.submit) }}*/
/*                 {{ form_end(form) }}</div>*/
/*             <br/>*/
/*         </div>*/
/*     {% endif %}*/
/* {% endblock %}*/
/* {% block documentReady %}*/
/*     $('#form1').submit(function(event){*/
/*     var data="";*/
/*     $.ajax({*/
/*             type: "POST",*/
/*             url: "{{ path('paragon_run_sheets_report') }}",*/
/*             data: data,*/
/*             dataType: "json",*/
/*             success: function(response)*/
/*             {   */
/*                 alert('Good');*/
/*             },*/
/* */
/*             error: function(XMLHttpRequest, textStatus, errorThrown)*/
/*             {*/
/*                 alert('Error : ' + errorThrown);*/
/*             },*/
/*             });*/
/*          */
/* }*/
/* )*/
/* */
/* {% endblock documentReady %}*/
/* */
