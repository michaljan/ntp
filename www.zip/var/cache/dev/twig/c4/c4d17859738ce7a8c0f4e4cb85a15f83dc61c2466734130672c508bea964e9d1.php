<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_27a6370d550d34da388a13b451320de7489a729aca390de6d8ff4774cca99754 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7f36f88ffe8ee8521a39d03bb81711deed2a20296cf450d4837b6bd8300d46a0 = $this->env->getExtension("native_profiler");
        $__internal_7f36f88ffe8ee8521a39d03bb81711deed2a20296cf450d4837b6bd8300d46a0->enter($__internal_7f36f88ffe8ee8521a39d03bb81711deed2a20296cf450d4837b6bd8300d46a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_7f36f88ffe8ee8521a39d03bb81711deed2a20296cf450d4837b6bd8300d46a0->leave($__internal_7f36f88ffe8ee8521a39d03bb81711deed2a20296cf450d4837b6bd8300d46a0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */
