<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_dd80f0185791f80a52d55edcfc51d8780a2613b29329f0b31822bf3bfddc35d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f518d29d04b70cf416f4207a25aca00a684605867226cddf64dba8d03c09bbf2 = $this->env->getExtension("native_profiler");
        $__internal_f518d29d04b70cf416f4207a25aca00a684605867226cddf64dba8d03c09bbf2->enter($__internal_f518d29d04b70cf416f4207a25aca00a684605867226cddf64dba8d03c09bbf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f518d29d04b70cf416f4207a25aca00a684605867226cddf64dba8d03c09bbf2->leave($__internal_f518d29d04b70cf416f4207a25aca00a684605867226cddf64dba8d03c09bbf2_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_a1c664875cee80c5f3275d76121725b1a78eea55286e02212ed6d40a9976aa97 = $this->env->getExtension("native_profiler");
        $__internal_a1c664875cee80c5f3275d76121725b1a78eea55286e02212ed6d40a9976aa97->enter($__internal_a1c664875cee80c5f3275d76121725b1a78eea55286e02212ed6d40a9976aa97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_a1c664875cee80c5f3275d76121725b1a78eea55286e02212ed6d40a9976aa97->leave($__internal_a1c664875cee80c5f3275d76121725b1a78eea55286e02212ed6d40a9976aa97_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:list_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
