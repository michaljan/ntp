<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_2f4cb4f050ed5e05e53f0e379d07faf44973f06cf602f9237918c1ad4a11e7cd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9e3c11fd348873c805fb5a95030fc18c0309746aff972d2f9cc263e175ba87b0 = $this->env->getExtension("native_profiler");
        $__internal_9e3c11fd348873c805fb5a95030fc18c0309746aff972d2f9cc263e175ba87b0->enter($__internal_9e3c11fd348873c805fb5a95030fc18c0309746aff972d2f9cc263e175ba87b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_9e3c11fd348873c805fb5a95030fc18c0309746aff972d2f9cc263e175ba87b0->leave($__internal_9e3c11fd348873c805fb5a95030fc18c0309746aff972d2f9cc263e175ba87b0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
