<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_acd2368f5ab1d53076fc34290de187d038679639d5e1e4f362126ddbdbe36d0d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_39abf8fb345c69b5e25058314dcaa8f07a9612797c8971c9002296348ab21ed0 = $this->env->getExtension("native_profiler");
        $__internal_39abf8fb345c69b5e25058314dcaa8f07a9612797c8971c9002296348ab21ed0->enter($__internal_39abf8fb345c69b5e25058314dcaa8f07a9612797c8971c9002296348ab21ed0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_39abf8fb345c69b5e25058314dcaa8f07a9612797c8971c9002296348ab21ed0->leave($__internal_39abf8fb345c69b5e25058314dcaa8f07a9612797c8971c9002296348ab21ed0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */
