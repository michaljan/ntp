<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_275531ef5d000226462d43204c80d545f64b02a216190eb913ab6ec5fb618061 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b392211ceb6959fd3f3449241a8d46fcd9fbdad4292ba60122428f3a3ed2c3f6 = $this->env->getExtension("native_profiler");
        $__internal_b392211ceb6959fd3f3449241a8d46fcd9fbdad4292ba60122428f3a3ed2c3f6->enter($__internal_b392211ceb6959fd3f3449241a8d46fcd9fbdad4292ba60122428f3a3ed2c3f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_b392211ceb6959fd3f3449241a8d46fcd9fbdad4292ba60122428f3a3ed2c3f6->leave($__internal_b392211ceb6959fd3f3449241a8d46fcd9fbdad4292ba60122428f3a3ed2c3f6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
