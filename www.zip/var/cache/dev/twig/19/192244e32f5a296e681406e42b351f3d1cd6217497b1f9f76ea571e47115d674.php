<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_61a1a802f2bfa434c6ce315945de394bc8c21026daea3e8d1226b17fae6ba0c2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6f71b13efde75cb78ad1c4548c2f73b8b572d16b2360db423a0694b696a5e4be = $this->env->getExtension("native_profiler");
        $__internal_6f71b13efde75cb78ad1c4548c2f73b8b572d16b2360db423a0694b696a5e4be->enter($__internal_6f71b13efde75cb78ad1c4548c2f73b8b572d16b2360db423a0694b696a5e4be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_6f71b13efde75cb78ad1c4548c2f73b8b572d16b2360db423a0694b696a5e4be->leave($__internal_6f71b13efde75cb78ad1c4548c2f73b8b572d16b2360db423a0694b696a5e4be_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
