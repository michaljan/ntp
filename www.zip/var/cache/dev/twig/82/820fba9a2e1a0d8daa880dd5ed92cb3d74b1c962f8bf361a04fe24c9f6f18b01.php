<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_8ea830078366b43481c2f9fdfd09b9526c53dea1512447e62bb54193176384d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_07f6a578578a972f542be3051f42014f21dc11f564fb060c5a357c9dc9a4008a = $this->env->getExtension("native_profiler");
        $__internal_07f6a578578a972f542be3051f42014f21dc11f564fb060c5a357c9dc9a4008a->enter($__internal_07f6a578578a972f542be3051f42014f21dc11f564fb060c5a357c9dc9a4008a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_07f6a578578a972f542be3051f42014f21dc11f564fb060c5a357c9dc9a4008a->leave($__internal_07f6a578578a972f542be3051f42014f21dc11f564fb060c5a357c9dc9a4008a_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_682d9b7279d1bc4e1fa37ef548c049fe95f65db4d85a77b9b3dd816e90e6def5 = $this->env->getExtension("native_profiler");
        $__internal_682d9b7279d1bc4e1fa37ef548c049fe95f65db4d85a77b9b3dd816e90e6def5->enter($__internal_682d9b7279d1bc4e1fa37ef548c049fe95f65db4d85a77b9b3dd816e90e6def5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_682d9b7279d1bc4e1fa37ef548c049fe95f65db4d85a77b9b3dd816e90e6def5->leave($__internal_682d9b7279d1bc4e1fa37ef548c049fe95f65db4d85a77b9b3dd816e90e6def5_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
