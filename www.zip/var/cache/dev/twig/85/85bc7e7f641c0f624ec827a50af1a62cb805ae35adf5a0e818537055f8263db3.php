<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_7cde293dee03a4622c059ac3d5ffa88bbf0a803f9537a724a0bf6b0d890c988e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca9d36d4dc1c21039bc3a1e300b495791e13324a4d4cf96eccf0e0bd07a4f1dd = $this->env->getExtension("native_profiler");
        $__internal_ca9d36d4dc1c21039bc3a1e300b495791e13324a4d4cf96eccf0e0bd07a4f1dd->enter($__internal_ca9d36d4dc1c21039bc3a1e300b495791e13324a4d4cf96eccf0e0bd07a4f1dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_ca9d36d4dc1c21039bc3a1e300b495791e13324a4d4cf96eccf0e0bd07a4f1dd->leave($__internal_ca9d36d4dc1c21039bc3a1e300b495791e13324a4d4cf96eccf0e0bd07a4f1dd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */
