<?php

/* @Twig/Exception/error.xml.twig */
class __TwigTemplate_3412132ed13e4d10a0246daa672e8e5a0598681730d8e8572001118f34991b40 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_33a290a171b15032de037f5a626dbdd2542dcd400e49f83b09390f11c77e7806 = $this->env->getExtension("native_profiler");
        $__internal_33a290a171b15032de037f5a626dbdd2542dcd400e49f83b09390f11c77e7806->enter($__internal_33a290a171b15032de037f5a626dbdd2542dcd400e49f83b09390f11c77e7806_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"";
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" ?>

<error code=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo "\" message=\"";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo "\" />
";
        
        $__internal_33a290a171b15032de037f5a626dbdd2542dcd400e49f83b09390f11c77e7806->leave($__internal_33a290a171b15032de037f5a626dbdd2542dcd400e49f83b09390f11c77e7806_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 3,  22 => 1,);
    }
}
/* <?xml version="1.0" encoding="{{ _charset }}" ?>*/
/* */
/* <error code="{{ status_code }}" message="{{ status_text }}" />*/
/* */
