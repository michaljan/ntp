<?php

/* @NTP/Reports/paragonRunSheetReport.html.twig */
class __TwigTemplate_697f910873705f72992b3537f7a574b74e8d2316c6c032a57a5cedef3d46fc59 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "@NTP/Reports/paragonRunSheetReport.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'documentReady' => array($this, 'block_documentReady'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_62ef1dbc42a55b107acdd36ad3351cc7080955fcb5cd1a1336ffa264a93b582d = $this->env->getExtension("native_profiler");
        $__internal_62ef1dbc42a55b107acdd36ad3351cc7080955fcb5cd1a1336ffa264a93b582d->enter($__internal_62ef1dbc42a55b107acdd36ad3351cc7080955fcb5cd1a1336ffa264a93b582d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@NTP/Reports/paragonRunSheetReport.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_62ef1dbc42a55b107acdd36ad3351cc7080955fcb5cd1a1336ffa264a93b582d->leave($__internal_62ef1dbc42a55b107acdd36ad3351cc7080955fcb5cd1a1336ffa264a93b582d_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_7def0fc2350b65fb14f78bb7632cb14055b22d53050666f6fb625dcaa8c11afd = $this->env->getExtension("native_profiler");
        $__internal_7def0fc2350b65fb14f78bb7632cb14055b22d53050666f6fb625dcaa8c11afd->enter($__internal_7def0fc2350b65fb14f78bb7632cb14055b22d53050666f6fb625dcaa8c11afd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    ";
        if ((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report"))) {
            echo "            
        <br/>
        <div class=\"row\">
            <div class=\"col-md-4\">
                <div class=\"row\">
                    <div class=\"col-md-5\">
                        ";
            // line 9
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("id" => "form_person_edit")));
            echo "
                        ";
            // line 10
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
                        ";
            // line 11
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "planDate", array()), 'row');
            echo "
                        ";
            // line 12
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
            echo "
                        ";
            // line 13
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
            echo "</div>
                    <div class=\"col-md-7\">
                    </div>
                </div>
            </div>
        </div>
    ";
        } else {
            // line 20
            echo "        <div class=\"row\">
            <div class=\"col-md-3\">
                ";
            // line 22
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("attr" => array("id" => "form1")));
            echo "
                ";
            // line 23
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
                ";
            // line 24
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "planDate", array()), 'row');
            echo "
                ";
            // line 25
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
            echo "
                ";
            // line 26
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
            echo "</div>
            <br/>
        </div>
    ";
        }
        
        $__internal_7def0fc2350b65fb14f78bb7632cb14055b22d53050666f6fb625dcaa8c11afd->leave($__internal_7def0fc2350b65fb14f78bb7632cb14055b22d53050666f6fb625dcaa8c11afd_prof);

    }

    // line 31
    public function block_documentReady($context, array $blocks = array())
    {
        $__internal_912002e96a8ae09b701b19ac75a1525742d4f5185f472cb88c9677a19925089d = $this->env->getExtension("native_profiler");
        $__internal_912002e96a8ae09b701b19ac75a1525742d4f5185f472cb88c9677a19925089d->enter($__internal_912002e96a8ae09b701b19ac75a1525742d4f5185f472cb88c9677a19925089d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "documentReady"));

        // line 32
        echo "    \$('#form1').submit(function(event){
    var data=\"\";
    \$.ajax({
            type: \"POST\",
            url: \"";
        // line 36
        echo $this->env->getExtension('routing')->getPath("paragon_run_sheets_report");
        echo "\",
            data: data,
            dataType: \"json\",
            success: function(response)
            {   
                alert('Good');
            },

            error: function(XMLHttpRequest, textStatus, errorThrown)
            {
                alert('Error : ' + errorThrown);
            },
            });
         
}
)

";
        
        $__internal_912002e96a8ae09b701b19ac75a1525742d4f5185f472cb88c9677a19925089d->leave($__internal_912002e96a8ae09b701b19ac75a1525742d4f5185f472cb88c9677a19925089d_prof);

    }

    public function getTemplateName()
    {
        return "@NTP/Reports/paragonRunSheetReport.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 36,  115 => 32,  109 => 31,  97 => 26,  93 => 25,  89 => 24,  85 => 23,  81 => 22,  77 => 20,  67 => 13,  63 => 12,  59 => 11,  55 => 10,  51 => 9,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     {% if report %}            */
/*         <br/>*/
/*         <div class="row">*/
/*             <div class="col-md-4">*/
/*                 <div class="row">*/
/*                     <div class="col-md-5">*/
/*                         {{ form_start(form,{'attr': {'id': 'form_person_edit'}}) }}*/
/*                         {{ form_errors(form) }}*/
/*                         {{ form_row(form.planDate) }}*/
/*                         {{ form_row(form.submit) }}*/
/*                         {{ form_end(form) }}</div>*/
/*                     <div class="col-md-7">*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     {% else %}*/
/*         <div class="row">*/
/*             <div class="col-md-3">*/
/*                 {{ form_start(form,{'attr': {'id': 'form1'}}) }}*/
/*                 {{ form_errors(form) }}*/
/*                 {{ form_row(form.planDate) }}*/
/*                 {{ form_row(form.submit) }}*/
/*                 {{ form_end(form) }}</div>*/
/*             <br/>*/
/*         </div>*/
/*     {% endif %}*/
/* {% endblock %}*/
/* {% block documentReady %}*/
/*     $('#form1').submit(function(event){*/
/*     var data="";*/
/*     $.ajax({*/
/*             type: "POST",*/
/*             url: "{{ path('paragon_run_sheets_report') }}",*/
/*             data: data,*/
/*             dataType: "json",*/
/*             success: function(response)*/
/*             {   */
/*                 alert('Good');*/
/*             },*/
/* */
/*             error: function(XMLHttpRequest, textStatus, errorThrown)*/
/*             {*/
/*                 alert('Error : ' + errorThrown);*/
/*             },*/
/*             });*/
/*          */
/* }*/
/* )*/
/* */
/* {% endblock documentReady %}*/
/* */
