<?php

/* @FOSUser/Resetting/passwordAlreadyRequested.html.twig */
class __TwigTemplate_6bac2418044c53a0fdae402ac38f6e7f63fdcee09d09ff5de34428825d08a717 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Resetting/passwordAlreadyRequested.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14db63593bef1a422548feea6d82f9bf12f17395f5857e084f3bc2e55dec1036 = $this->env->getExtension("native_profiler");
        $__internal_14db63593bef1a422548feea6d82f9bf12f17395f5857e084f3bc2e55dec1036->enter($__internal_14db63593bef1a422548feea6d82f9bf12f17395f5857e084f3bc2e55dec1036_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Resetting/passwordAlreadyRequested.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_14db63593bef1a422548feea6d82f9bf12f17395f5857e084f3bc2e55dec1036->leave($__internal_14db63593bef1a422548feea6d82f9bf12f17395f5857e084f3bc2e55dec1036_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_069c2b2bcf8a4f4a500a380696651aadea18850fd35eaed7373cbb24d3cc920b = $this->env->getExtension("native_profiler");
        $__internal_069c2b2bcf8a4f4a500a380696651aadea18850fd35eaed7373cbb24d3cc920b->enter($__internal_069c2b2bcf8a4f4a500a380696651aadea18850fd35eaed7373cbb24d3cc920b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_069c2b2bcf8a4f4a500a380696651aadea18850fd35eaed7373cbb24d3cc920b->leave($__internal_069c2b2bcf8a4f4a500a380696651aadea18850fd35eaed7373cbb24d3cc920b_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Resetting/passwordAlreadyRequested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>{{ 'resetting.password_already_requested'|trans }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
