<?php

/* @FOSUser/Resetting/checkEmail.html.twig */
class __TwigTemplate_6c23b1dab746004de237158592f592167a648afb957e8164235a6d1fb70fbcc7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Resetting/checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_401a9479d244003dd24580d2f526adcde92befd79aa21527bc121c61b5d88fd2 = $this->env->getExtension("native_profiler");
        $__internal_401a9479d244003dd24580d2f526adcde92befd79aa21527bc121c61b5d88fd2->enter($__internal_401a9479d244003dd24580d2f526adcde92befd79aa21527bc121c61b5d88fd2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Resetting/checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_401a9479d244003dd24580d2f526adcde92befd79aa21527bc121c61b5d88fd2->leave($__internal_401a9479d244003dd24580d2f526adcde92befd79aa21527bc121c61b5d88fd2_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_47f8f5fbf9210c83ebcc3e43409d443a1a3d33332975222b4ebc7225a4dd0eb2 = $this->env->getExtension("native_profiler");
        $__internal_47f8f5fbf9210c83ebcc3e43409d443a1a3d33332975222b4ebc7225a4dd0eb2->enter($__internal_47f8f5fbf9210c83ebcc3e43409d443a1a3d33332975222b4ebc7225a4dd0eb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.check_email", array("%email%" => (isset($context["email"]) ? $context["email"] : $this->getContext($context, "email"))), "FOSUserBundle"), "html", null, true);
        echo "
</p>
";
        
        $__internal_47f8f5fbf9210c83ebcc3e43409d443a1a3d33332975222b4ebc7225a4dd0eb2->leave($__internal_47f8f5fbf9210c83ebcc3e43409d443a1a3d33332975222b4ebc7225a4dd0eb2_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Resetting/checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>*/
/* {{ 'resetting.check_email'|trans({'%email%': email}) }}*/
/* </p>*/
/* {% endblock %}*/
/* */
