<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_5a717967743d20afd6e6e0862cb7f84d93cf0fa90fba856501348728ad78a04a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a2ff21487ef1fbad2f26c5be18310c1bef2f4f48a5c821487064a7465797051a = $this->env->getExtension("native_profiler");
        $__internal_a2ff21487ef1fbad2f26c5be18310c1bef2f4f48a5c821487064a7465797051a->enter($__internal_a2ff21487ef1fbad2f26c5be18310c1bef2f4f48a5c821487064a7465797051a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a2ff21487ef1fbad2f26c5be18310c1bef2f4f48a5c821487064a7465797051a->leave($__internal_a2ff21487ef1fbad2f26c5be18310c1bef2f4f48a5c821487064a7465797051a_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_366a0a908a167ca58053289c0ba02bfd2c2553651feb80f42c7881a0452b79aa = $this->env->getExtension("native_profiler");
        $__internal_366a0a908a167ca58053289c0ba02bfd2c2553651feb80f42c7881a0452b79aa->enter($__internal_366a0a908a167ca58053289c0ba02bfd2c2553651feb80f42c7881a0452b79aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_366a0a908a167ca58053289c0ba02bfd2c2553651feb80f42c7881a0452b79aa->leave($__internal_366a0a908a167ca58053289c0ba02bfd2c2553651feb80f42c7881a0452b79aa_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
