<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_8e618e2ebd88f5f63e882092e9ee1cc6fae2ecf271b3438dd134682e9bcc2e43 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f27b51ed1b61083324ccb86004518752d533164a96fecdbdc10dd186cf1af234 = $this->env->getExtension("native_profiler");
        $__internal_f27b51ed1b61083324ccb86004518752d533164a96fecdbdc10dd186cf1af234->enter($__internal_f27b51ed1b61083324ccb86004518752d533164a96fecdbdc10dd186cf1af234_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_f27b51ed1b61083324ccb86004518752d533164a96fecdbdc10dd186cf1af234->leave($__internal_f27b51ed1b61083324ccb86004518752d533164a96fecdbdc10dd186cf1af234_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
