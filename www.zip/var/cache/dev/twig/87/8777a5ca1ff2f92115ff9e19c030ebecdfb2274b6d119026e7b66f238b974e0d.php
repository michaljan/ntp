<?php

/* @NTP/Reports/tractorReport.html.twig */
class __TwigTemplate_6f08ddb20db18c45cb486c9c809cba6cce69e4a2c21ef3051a5745e40c561c7a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "@NTP/Reports/tractorReport.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'documentReady' => array($this, 'block_documentReady'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5db0ac759ab566f2bb902614eccd56a560cd0354ed2b3c8c00c2cac2f80043c4 = $this->env->getExtension("native_profiler");
        $__internal_5db0ac759ab566f2bb902614eccd56a560cd0354ed2b3c8c00c2cac2f80043c4->enter($__internal_5db0ac759ab566f2bb902614eccd56a560cd0354ed2b3c8c00c2cac2f80043c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@NTP/Reports/tractorReport.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5db0ac759ab566f2bb902614eccd56a560cd0354ed2b3c8c00c2cac2f80043c4->leave($__internal_5db0ac759ab566f2bb902614eccd56a560cd0354ed2b3c8c00c2cac2f80043c4_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_63373f989e2f7d4c2e1fe857fdd080470d9e4dea3ca6e05cc51d01949984a30f = $this->env->getExtension("native_profiler");
        $__internal_63373f989e2f7d4c2e1fe857fdd080470d9e4dea3ca6e05cc51d01949984a30f->enter($__internal_63373f989e2f7d4c2e1fe857fdd080470d9e4dea3ca6e05cc51d01949984a30f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        echo "          
    <br/>
    ";
        // line 4
        if ((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report"))) {
            // line 5
            echo "        
    <div class=\"row\">
        <div class=\"col-md-2\">
            ";
            // line 8
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
            echo "
            ";
            // line 9
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
            ";
            // line 10
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "startDate", array()), 'row');
            echo "
            ";
            // line 11
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "endDate", array()), 'row');
            echo "
            ";
            // line 12
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
            echo "
            ";
            // line 13
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
            echo "</div>
        <div class=\"col-md-10\">
                <div class=\"caption\"><h4>Total tractors usage</h4></div>
                <div id=\"bar-tractors\" style=\"height: 250px;\"></div>
        </div>
    </div>
    ";
        }
        // line 20
        echo "    
    
    <div class=\"row\">
        <div class=\"col-md-2\">
            ";
        // line 24
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
            ";
        // line 25
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "
            ";
        // line 26
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "startDate", array()), 'row');
        echo "
            ";
        // line 27
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "endDate", array()), 'row');
        echo "
            ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
        echo "
            ";
        // line 29
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "</div>
        <div class=\"col-md-10\">
        </div>
    </div>
";
        
        $__internal_63373f989e2f7d4c2e1fe857fdd080470d9e4dea3ca6e05cc51d01949984a30f->leave($__internal_63373f989e2f7d4c2e1fe857fdd080470d9e4dea3ca6e05cc51d01949984a30f_prof);

    }

    // line 34
    public function block_documentReady($context, array $blocks = array())
    {
        $__internal_524977b2a6c12fcfadd1ebd380434ba3f544c5e2d0f3070d8b27d5c9b023caca = $this->env->getExtension("native_profiler");
        $__internal_524977b2a6c12fcfadd1ebd380434ba3f544c5e2d0f3070d8b27d5c9b023caca->enter($__internal_524977b2a6c12fcfadd1ebd380434ba3f544c5e2d0f3070d8b27d5c9b023caca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "documentReady"));

        // line 35
        echo "    ";
        if ((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report"))) {
            // line 36
            echo "        var paragonTractors = ";
            echo $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "tractor", array());
            echo ";
    ";
        }
        // line 38
        echo "    Morris.Area({
    element: 'bar-tractors',
    hideHover: 'false',
    data: paragonTractors,
    xkey: 'a',
    ykeys: ['y'],
    labels: ['Runs'],
    gridTextSize: '10',
    stacked: true,
    resize: true,
    xLabelAngle: 55
    });

";
        
        $__internal_524977b2a6c12fcfadd1ebd380434ba3f544c5e2d0f3070d8b27d5c9b023caca->leave($__internal_524977b2a6c12fcfadd1ebd380434ba3f544c5e2d0f3070d8b27d5c9b023caca_prof);

    }

    public function getTemplateName()
    {
        return "@NTP/Reports/tractorReport.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 38,  128 => 36,  125 => 35,  119 => 34,  107 => 29,  103 => 28,  99 => 27,  95 => 26,  91 => 25,  87 => 24,  81 => 20,  71 => 13,  67 => 12,  63 => 11,  59 => 10,  55 => 9,  51 => 8,  46 => 5,  44 => 4,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}          */
/*     <br/>*/
/*     {% if report %}*/
/*         */
/*     <div class="row">*/
/*         <div class="col-md-2">*/
/*             {{ form_start(form) }}*/
/*             {{ form_errors(form) }}*/
/*             {{ form_row(form.startDate) }}*/
/*             {{ form_row(form.endDate) }}*/
/*             {{ form_row(form.submit) }}*/
/*             {{ form_end(form) }}</div>*/
/*         <div class="col-md-10">*/
/*                 <div class="caption"><h4>Total tractors usage</h4></div>*/
/*                 <div id="bar-tractors" style="height: 250px;"></div>*/
/*         </div>*/
/*     </div>*/
/*     {% endif %}*/
/*     */
/*     */
/*     <div class="row">*/
/*         <div class="col-md-2">*/
/*             {{ form_start(form) }}*/
/*             {{ form_errors(form) }}*/
/*             {{ form_row(form.startDate) }}*/
/*             {{ form_row(form.endDate) }}*/
/*             {{ form_row(form.submit) }}*/
/*             {{ form_end(form) }}</div>*/
/*         <div class="col-md-10">*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* {% block documentReady %}*/
/*     {% if report %}*/
/*         var paragonTractors = {{ report.tractor | raw }};*/
/*     {% endif %}*/
/*     Morris.Area({*/
/*     element: 'bar-tractors',*/
/*     hideHover: 'false',*/
/*     data: paragonTractors,*/
/*     xkey: 'a',*/
/*     ykeys: ['y'],*/
/*     labels: ['Runs'],*/
/*     gridTextSize: '10',*/
/*     stacked: true,*/
/*     resize: true,*/
/*     xLabelAngle: 55*/
/*     });*/
/* */
/* {% endblock documentReady %}*/
/* */
/* */
/* */
