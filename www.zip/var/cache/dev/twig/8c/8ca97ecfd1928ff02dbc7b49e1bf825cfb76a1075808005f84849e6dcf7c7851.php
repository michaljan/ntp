<?php

/* @FOSUser/Security/login.html.twig */
class __TwigTemplate_bb3d4012c12653e36884d4c278b5397e39e7a59ad899f1f8c7d0a3f4a1dc0eda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "@FOSUser/Security/login.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dce540bf08a0026f8a2daa44f7ea0f1cd44bdd69635eed769457e53c3c21f06a = $this->env->getExtension("native_profiler");
        $__internal_dce540bf08a0026f8a2daa44f7ea0f1cd44bdd69635eed769457e53c3c21f06a->enter($__internal_dce540bf08a0026f8a2daa44f7ea0f1cd44bdd69635eed769457e53c3c21f06a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dce540bf08a0026f8a2daa44f7ea0f1cd44bdd69635eed769457e53c3c21f06a->leave($__internal_dce540bf08a0026f8a2daa44f7ea0f1cd44bdd69635eed769457e53c3c21f06a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_e52fd445f50e8c3a12c7c2bff001873e02b8a673fd28331bedfa7055b0746abe = $this->env->getExtension("native_profiler");
        $__internal_e52fd445f50e8c3a12c7c2bff001873e02b8a673fd28331bedfa7055b0746abe->enter($__internal_e52fd445f50e8c3a12c7c2bff001873e02b8a673fd28331bedfa7055b0746abe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "        ";
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 5
            echo "            <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), array(), "FOSUserBundle"), "html", null, true);
            echo "</div>
        ";
        }
        // line 7
        echo "    <div class=\"body-login-background\">
        <div class=\"body-login-container\">
        <form action=\"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("fos_user_security_check");
        echo "\" method=\"post\">
            <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 10
        echo twig_escape_filter($this->env, (isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token")), "html", null, true);
        echo "\" />
            <div class=\"form-group\">
                <label for=\"username\">";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("security.login.username", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                <input class=\"form-control\" type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" required=\"required\" />
            </div>
            <div class=\"form-group\">
                <label for=\"password\">";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("security.login.password", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
                <input class=\"form-control\" type=\"password\" id=\"password\" name=\"_password\" required=\"required\" />
            </div>
            <div class=\"checkbox\">
                <input type=\"checkbox\" id=\"remember_me\" name=\"_remember_me\" value=\"on\" />
                <label for=\"remember_me\">";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("security.login.remember_me", array(), "FOSUserBundle"), "html", null, true);
        echo "</label>
            </div>
            <input class=\"btn btn-default\" type=\"submit\" id=\"_submit\" name=\"_submit\" value=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("security.login.submit", array(), "FOSUserBundle"), "html", null, true);
        echo "\" />
        </form>
        </div>
    </div>
        
    
";
        
        $__internal_e52fd445f50e8c3a12c7c2bff001873e02b8a673fd28331bedfa7055b0746abe->leave($__internal_e52fd445f50e8c3a12c7c2bff001873e02b8a673fd28331bedfa7055b0746abe_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 23,  80 => 21,  72 => 16,  66 => 13,  62 => 12,  57 => 10,  53 => 9,  49 => 7,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block body %}*/
/*         {% if error %}*/
/*             <div>{{ error|trans }}</div>*/
/*         {% endif %}*/
/*     <div class="body-login-background">*/
/*         <div class="body-login-container">*/
/*         <form action="{{ path("fos_user_security_check") }}" method="post">*/
/*             <input type="hidden" name="_csrf_token" value="{{ csrf_token }}" />*/
/*             <div class="form-group">*/
/*                 <label for="username">{{ 'security.login.username'|trans }}</label>*/
/*                 <input class="form-control" type="text" id="username" name="_username" value="{{ last_username }}" required="required" />*/
/*             </div>*/
/*             <div class="form-group">*/
/*                 <label for="password">{{ 'security.login.password'|trans }}</label>*/
/*                 <input class="form-control" type="password" id="password" name="_password" required="required" />*/
/*             </div>*/
/*             <div class="checkbox">*/
/*                 <input type="checkbox" id="remember_me" name="_remember_me" value="on" />*/
/*                 <label for="remember_me">{{ 'security.login.remember_me'|trans }}</label>*/
/*             </div>*/
/*             <input class="btn btn-default" type="submit" id="_submit" name="_submit" value="{{ 'security.login.submit'|trans }}" />*/
/*         </form>*/
/*         </div>*/
/*     </div>*/
/*         */
/*     */
/* {% endblock %}*/
