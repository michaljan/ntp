<?php

/* @FOSUser/Group/show.html.twig */
class __TwigTemplate_0cd9e1c47a7d4629fb598c88040809fc12dd3f720863ae33669e92f7bd925fcf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Group/show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_661550ac7df817367c6030eb192481da9a3c1895af57d1a6550b16ec2fb1a496 = $this->env->getExtension("native_profiler");
        $__internal_661550ac7df817367c6030eb192481da9a3c1895af57d1a6550b16ec2fb1a496->enter($__internal_661550ac7df817367c6030eb192481da9a3c1895af57d1a6550b16ec2fb1a496_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_661550ac7df817367c6030eb192481da9a3c1895af57d1a6550b16ec2fb1a496->leave($__internal_661550ac7df817367c6030eb192481da9a3c1895af57d1a6550b16ec2fb1a496_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_d2a613f687351c48731e8d876a87aba88cab3c14db6e7e71538213f0fdfad77f = $this->env->getExtension("native_profiler");
        $__internal_d2a613f687351c48731e8d876a87aba88cab3c14db6e7e71538213f0fdfad77f->enter($__internal_d2a613f687351c48731e8d876a87aba88cab3c14db6e7e71538213f0fdfad77f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "@FOSUser/Group/show.html.twig", 4)->display($context);
        
        $__internal_d2a613f687351c48731e8d876a87aba88cab3c14db6e7e71538213f0fdfad77f->leave($__internal_d2a613f687351c48731e8d876a87aba88cab3c14db6e7e71538213f0fdfad77f_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
