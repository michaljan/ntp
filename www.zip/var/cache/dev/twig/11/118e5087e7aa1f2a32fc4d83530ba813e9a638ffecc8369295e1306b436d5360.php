<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_991ef12cf08be3bd4635bf9ad1a92b1591cc1924697320792e5f8eb884524be7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8fb2016c2cda69ed489ae27897df9250b87c5d3d446eea35391bb85160493eac = $this->env->getExtension("native_profiler");
        $__internal_8fb2016c2cda69ed489ae27897df9250b87c5d3d446eea35391bb85160493eac->enter($__internal_8fb2016c2cda69ed489ae27897df9250b87c5d3d446eea35391bb85160493eac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8fb2016c2cda69ed489ae27897df9250b87c5d3d446eea35391bb85160493eac->leave($__internal_8fb2016c2cda69ed489ae27897df9250b87c5d3d446eea35391bb85160493eac_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_21b55cfabe097b34316744f32c9bc5fab16f94b903f25f44119a184dbf1f8eb9 = $this->env->getExtension("native_profiler");
        $__internal_21b55cfabe097b34316744f32c9bc5fab16f94b903f25f44119a184dbf1f8eb9->enter($__internal_21b55cfabe097b34316744f32c9bc5fab16f94b903f25f44119a184dbf1f8eb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_21b55cfabe097b34316744f32c9bc5fab16f94b903f25f44119a184dbf1f8eb9->leave($__internal_21b55cfabe097b34316744f32c9bc5fab16f94b903f25f44119a184dbf1f8eb9_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_cf6e8f91e97d0eac3f57a45bb595c11a0b553152cde281d91b33e889106d207b = $this->env->getExtension("native_profiler");
        $__internal_cf6e8f91e97d0eac3f57a45bb595c11a0b553152cde281d91b33e889106d207b->enter($__internal_cf6e8f91e97d0eac3f57a45bb595c11a0b553152cde281d91b33e889106d207b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_cf6e8f91e97d0eac3f57a45bb595c11a0b553152cde281d91b33e889106d207b->leave($__internal_cf6e8f91e97d0eac3f57a45bb595c11a0b553152cde281d91b33e889106d207b_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_f519fb60385a525670907c4980748bed0fd151e032c78f43b6fa61050e224e2d = $this->env->getExtension("native_profiler");
        $__internal_f519fb60385a525670907c4980748bed0fd151e032c78f43b6fa61050e224e2d->enter($__internal_f519fb60385a525670907c4980748bed0fd151e032c78f43b6fa61050e224e2d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_f519fb60385a525670907c4980748bed0fd151e032c78f43b6fa61050e224e2d->leave($__internal_f519fb60385a525670907c4980748bed0fd151e032c78f43b6fa61050e224e2d_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
