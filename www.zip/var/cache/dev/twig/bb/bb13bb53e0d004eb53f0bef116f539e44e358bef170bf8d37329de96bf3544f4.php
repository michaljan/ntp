<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_d2b8392dd06759555bec915e55da9f14c2d8afd17f41730ffaaf8ffa79085aea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_deff3cf329437f8a2a9ee6805caf0d0ca33ee2da96ff974fcff05310dbe1e6cf = $this->env->getExtension("native_profiler");
        $__internal_deff3cf329437f8a2a9ee6805caf0d0ca33ee2da96ff974fcff05310dbe1e6cf->enter($__internal_deff3cf329437f8a2a9ee6805caf0d0ca33ee2da96ff974fcff05310dbe1e6cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_deff3cf329437f8a2a9ee6805caf0d0ca33ee2da96ff974fcff05310dbe1e6cf->leave($__internal_deff3cf329437f8a2a9ee6805caf0d0ca33ee2da96ff974fcff05310dbe1e6cf_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_41cb0e6fcda24c2894c3b04db6c11f4b7d70a542f6051698d478cff42b2095f3 = $this->env->getExtension("native_profiler");
        $__internal_41cb0e6fcda24c2894c3b04db6c11f4b7d70a542f6051698d478cff42b2095f3->enter($__internal_41cb0e6fcda24c2894c3b04db6c11f4b7d70a542f6051698d478cff42b2095f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("resetting.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        echo "
";
        
        $__internal_41cb0e6fcda24c2894c3b04db6c11f4b7d70a542f6051698d478cff42b2095f3->leave($__internal_41cb0e6fcda24c2894c3b04db6c11f4b7d70a542f6051698d478cff42b2095f3_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_87a7c54cbbda1e72e584f3395177daf56e777e9164ed4e8dd2ed6f8c26b1a23b = $this->env->getExtension("native_profiler");
        $__internal_87a7c54cbbda1e72e584f3395177daf56e777e9164ed4e8dd2ed6f8c26b1a23b->enter($__internal_87a7c54cbbda1e72e584f3395177daf56e777e9164ed4e8dd2ed6f8c26b1a23b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_87a7c54cbbda1e72e584f3395177daf56e777e9164ed4e8dd2ed6f8c26b1a23b->leave($__internal_87a7c54cbbda1e72e584f3395177daf56e777e9164ed4e8dd2ed6f8c26b1a23b_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_790ab9a4a1a6fce37aee9fd0ab3eceede6aa7541132de1aa56908036b4074f92 = $this->env->getExtension("native_profiler");
        $__internal_790ab9a4a1a6fce37aee9fd0ab3eceede6aa7541132de1aa56908036b4074f92->enter($__internal_790ab9a4a1a6fce37aee9fd0ab3eceede6aa7541132de1aa56908036b4074f92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_790ab9a4a1a6fce37aee9fd0ab3eceede6aa7541132de1aa56908036b4074f92->leave($__internal_790ab9a4a1a6fce37aee9fd0ab3eceede6aa7541132de1aa56908036b4074f92_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.subject'|trans({'%username%': user.username}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
