<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_4d90c2860077ab21f7334780e2390ef1632b5e7f46791f67d5187b668b974ac9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0bd55613c1b457c4dda99a1c7057bb384c173d9b4d0c1688425844482601206e = $this->env->getExtension("native_profiler");
        $__internal_0bd55613c1b457c4dda99a1c7057bb384c173d9b4d0c1688425844482601206e->enter($__internal_0bd55613c1b457c4dda99a1c7057bb384c173d9b4d0c1688425844482601206e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_0bd55613c1b457c4dda99a1c7057bb384c173d9b4d0c1688425844482601206e->leave($__internal_0bd55613c1b457c4dda99a1c7057bb384c173d9b4d0c1688425844482601206e_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
