<?php

/* NTPBundle:Reports:tractorReport.html.twig */
class __TwigTemplate_086476b2c5f96e50b34cbde609ab07cc6bf4927897a6222d0b5a1940eacde556 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "NTPBundle:Reports:tractorReport.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'documentReady' => array($this, 'block_documentReady'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fee790c7a072227c8025b81df3fb5ad638d80ce8735ec4713afe2498b8c9da6a = $this->env->getExtension("native_profiler");
        $__internal_fee790c7a072227c8025b81df3fb5ad638d80ce8735ec4713afe2498b8c9da6a->enter($__internal_fee790c7a072227c8025b81df3fb5ad638d80ce8735ec4713afe2498b8c9da6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NTPBundle:Reports:tractorReport.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fee790c7a072227c8025b81df3fb5ad638d80ce8735ec4713afe2498b8c9da6a->leave($__internal_fee790c7a072227c8025b81df3fb5ad638d80ce8735ec4713afe2498b8c9da6a_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_67f9605ab51c894cd7b9350abed96e1c9a7cc8005dde7a24ad29a9cbe53be996 = $this->env->getExtension("native_profiler");
        $__internal_67f9605ab51c894cd7b9350abed96e1c9a7cc8005dde7a24ad29a9cbe53be996->enter($__internal_67f9605ab51c894cd7b9350abed96e1c9a7cc8005dde7a24ad29a9cbe53be996_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        echo "          
    <br/>
    ";
        // line 4
        if ((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report"))) {
            // line 5
            echo "        
    <div class=\"row\">
        <div class=\"col-md-2\">
            ";
            // line 8
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
            echo "
            ";
            // line 9
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
            ";
            // line 10
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "startDate", array()), 'row');
            echo "
            ";
            // line 11
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "endDate", array()), 'row');
            echo "
            ";
            // line 12
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
            echo "
            ";
            // line 13
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
            echo "</div>
        <div class=\"col-md-10\">
                <div class=\"caption\"><h4>Total tractors usage</h4></div>
                <div id=\"bar-tractors\" style=\"height: 250px;\"></div>
        </div>
    </div>
    ";
        }
        // line 20
        echo "    
    
    <div class=\"row\">
        <div class=\"col-md-2\">
            ";
        // line 24
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
            ";
        // line 25
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "
            ";
        // line 26
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "startDate", array()), 'row');
        echo "
            ";
        // line 27
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "endDate", array()), 'row');
        echo "
            ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
        echo "
            ";
        // line 29
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "</div>
        <div class=\"col-md-10\">
        </div>
    </div>
";
        
        $__internal_67f9605ab51c894cd7b9350abed96e1c9a7cc8005dde7a24ad29a9cbe53be996->leave($__internal_67f9605ab51c894cd7b9350abed96e1c9a7cc8005dde7a24ad29a9cbe53be996_prof);

    }

    // line 34
    public function block_documentReady($context, array $blocks = array())
    {
        $__internal_6f24fa7619daefa5606164eee9b59b360ff2e54eabb7abeb18aa08d245d92287 = $this->env->getExtension("native_profiler");
        $__internal_6f24fa7619daefa5606164eee9b59b360ff2e54eabb7abeb18aa08d245d92287->enter($__internal_6f24fa7619daefa5606164eee9b59b360ff2e54eabb7abeb18aa08d245d92287_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "documentReady"));

        // line 35
        echo "    ";
        if ((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report"))) {
            // line 36
            echo "        var paragonTractors = ";
            echo $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "tractor", array());
            echo ";
    ";
        }
        // line 38
        echo "    Morris.Area({
    element: 'bar-tractors',
    hideHover: 'false',
    data: paragonTractors,
    xkey: 'a',
    ykeys: ['y'],
    labels: ['Runs'],
    gridTextSize: '10',
    stacked: true,
    resize: true,
    xLabelAngle: 55
    });

";
        
        $__internal_6f24fa7619daefa5606164eee9b59b360ff2e54eabb7abeb18aa08d245d92287->leave($__internal_6f24fa7619daefa5606164eee9b59b360ff2e54eabb7abeb18aa08d245d92287_prof);

    }

    public function getTemplateName()
    {
        return "NTPBundle:Reports:tractorReport.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 38,  128 => 36,  125 => 35,  119 => 34,  107 => 29,  103 => 28,  99 => 27,  95 => 26,  91 => 25,  87 => 24,  81 => 20,  71 => 13,  67 => 12,  63 => 11,  59 => 10,  55 => 9,  51 => 8,  46 => 5,  44 => 4,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}          */
/*     <br/>*/
/*     {% if report %}*/
/*         */
/*     <div class="row">*/
/*         <div class="col-md-2">*/
/*             {{ form_start(form) }}*/
/*             {{ form_errors(form) }}*/
/*             {{ form_row(form.startDate) }}*/
/*             {{ form_row(form.endDate) }}*/
/*             {{ form_row(form.submit) }}*/
/*             {{ form_end(form) }}</div>*/
/*         <div class="col-md-10">*/
/*                 <div class="caption"><h4>Total tractors usage</h4></div>*/
/*                 <div id="bar-tractors" style="height: 250px;"></div>*/
/*         </div>*/
/*     </div>*/
/*     {% endif %}*/
/*     */
/*     */
/*     <div class="row">*/
/*         <div class="col-md-2">*/
/*             {{ form_start(form) }}*/
/*             {{ form_errors(form) }}*/
/*             {{ form_row(form.startDate) }}*/
/*             {{ form_row(form.endDate) }}*/
/*             {{ form_row(form.submit) }}*/
/*             {{ form_end(form) }}</div>*/
/*         <div class="col-md-10">*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* {% block documentReady %}*/
/*     {% if report %}*/
/*         var paragonTractors = {{ report.tractor | raw }};*/
/*     {% endif %}*/
/*     Morris.Area({*/
/*     element: 'bar-tractors',*/
/*     hideHover: 'false',*/
/*     data: paragonTractors,*/
/*     xkey: 'a',*/
/*     ykeys: ['y'],*/
/*     labels: ['Runs'],*/
/*     gridTextSize: '10',*/
/*     stacked: true,*/
/*     resize: true,*/
/*     xLabelAngle: 55*/
/*     });*/
/* */
/* {% endblock documentReady %}*/
/* */
/* */
/* */
