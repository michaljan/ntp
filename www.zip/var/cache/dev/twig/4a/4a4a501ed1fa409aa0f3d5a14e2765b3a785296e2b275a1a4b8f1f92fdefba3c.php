<?php

/* @FOSUser/Registration/register.html.twig */
class __TwigTemplate_8583973a52c9f4f785f6560ae665a988b1bceebb246d5f4c15f63bf6b5edfd62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Registration/register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_94ae75f86a4f6e1de4fde1ea851b0f25bac41913a0d24e01922fcfbee576b51e = $this->env->getExtension("native_profiler");
        $__internal_94ae75f86a4f6e1de4fde1ea851b0f25bac41913a0d24e01922fcfbee576b51e->enter($__internal_94ae75f86a4f6e1de4fde1ea851b0f25bac41913a0d24e01922fcfbee576b51e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Registration/register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_94ae75f86a4f6e1de4fde1ea851b0f25bac41913a0d24e01922fcfbee576b51e->leave($__internal_94ae75f86a4f6e1de4fde1ea851b0f25bac41913a0d24e01922fcfbee576b51e_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b0bb812606571da677068677e95833d5ee10a7ae83bb935a3749c87520ba881e = $this->env->getExtension("native_profiler");
        $__internal_b0bb812606571da677068677e95833d5ee10a7ae83bb935a3749c87520ba881e->enter($__internal_b0bb812606571da677068677e95833d5ee10a7ae83bb935a3749c87520ba881e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "@FOSUser/Registration/register.html.twig", 4)->display($context);
        
        $__internal_b0bb812606571da677068677e95833d5ee10a7ae83bb935a3749c87520ba881e->leave($__internal_b0bb812606571da677068677e95833d5ee10a7ae83bb935a3749c87520ba881e_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Registration/register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
