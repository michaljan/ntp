<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_32ecb7de16abd2b869e8d5bcd5597ef3642b1374e3b57bd338ecc1a3857952e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_434e4b72b3b7b6aaf55d60c53d5710a7e5b44bf964edd766cb94a39144caeadb = $this->env->getExtension("native_profiler");
        $__internal_434e4b72b3b7b6aaf55d60c53d5710a7e5b44bf964edd766cb94a39144caeadb->enter($__internal_434e4b72b3b7b6aaf55d60c53d5710a7e5b44bf964edd766cb94a39144caeadb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_434e4b72b3b7b6aaf55d60c53d5710a7e5b44bf964edd766cb94a39144caeadb->leave($__internal_434e4b72b3b7b6aaf55d60c53d5710a7e5b44bf964edd766cb94a39144caeadb_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
