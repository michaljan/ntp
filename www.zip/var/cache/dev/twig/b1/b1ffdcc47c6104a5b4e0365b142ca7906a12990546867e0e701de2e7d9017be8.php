<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_fd02e8f7c2e2067d42b663600e3f1a0397917052b0b46aa7b4304f0209ce16ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b5a6d9bd59fe7bda635669dfb587c2f06685fd2e3b2ac07d43af5b53e290176b = $this->env->getExtension("native_profiler");
        $__internal_b5a6d9bd59fe7bda635669dfb587c2f06685fd2e3b2ac07d43af5b53e290176b->enter($__internal_b5a6d9bd59fe7bda635669dfb587c2f06685fd2e3b2ac07d43af5b53e290176b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_b5a6d9bd59fe7bda635669dfb587c2f06685fd2e3b2ac07d43af5b53e290176b->leave($__internal_b5a6d9bd59fe7bda635669dfb587c2f06685fd2e3b2ac07d43af5b53e290176b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($compound): ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_compound')?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_simple')?>*/
/* <?php endif ?>*/
/* */
