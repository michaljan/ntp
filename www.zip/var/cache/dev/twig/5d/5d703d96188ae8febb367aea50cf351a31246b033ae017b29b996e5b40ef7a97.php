<?php

/* @FOSUser/Group/new.html.twig */
class __TwigTemplate_b9a92c44e5ddb00aa2d8b64a310af3b58dc96a910d3b5b609cd4658b527e3b3d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Group/new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8846b5fb67a7091c3fbf6f442d2aeae00cdc867306c424f968cf7afbfd123e3d = $this->env->getExtension("native_profiler");
        $__internal_8846b5fb67a7091c3fbf6f442d2aeae00cdc867306c424f968cf7afbfd123e3d->enter($__internal_8846b5fb67a7091c3fbf6f442d2aeae00cdc867306c424f968cf7afbfd123e3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Group/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8846b5fb67a7091c3fbf6f442d2aeae00cdc867306c424f968cf7afbfd123e3d->leave($__internal_8846b5fb67a7091c3fbf6f442d2aeae00cdc867306c424f968cf7afbfd123e3d_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_92ca70ae61f4276fb0081f97205e5b4a179bec5da54b8e28c29ab91721de614e = $this->env->getExtension("native_profiler");
        $__internal_92ca70ae61f4276fb0081f97205e5b4a179bec5da54b8e28c29ab91721de614e->enter($__internal_92ca70ae61f4276fb0081f97205e5b4a179bec5da54b8e28c29ab91721de614e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:new_content.html.twig", "@FOSUser/Group/new.html.twig", 4)->display($context);
        
        $__internal_92ca70ae61f4276fb0081f97205e5b4a179bec5da54b8e28c29ab91721de614e->leave($__internal_92ca70ae61f4276fb0081f97205e5b4a179bec5da54b8e28c29ab91721de614e_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Group/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:new_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
