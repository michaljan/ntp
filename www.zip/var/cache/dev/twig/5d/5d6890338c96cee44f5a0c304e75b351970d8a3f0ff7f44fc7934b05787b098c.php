<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_d277d3976b9a3be649fa1b89bea2907ba78995a1eda79b537b7170317da8577b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_11fc3904cf89a49ba64ec1f2db6475d66ab7966496aa566438d3a58eba960998 = $this->env->getExtension("native_profiler");
        $__internal_11fc3904cf89a49ba64ec1f2db6475d66ab7966496aa566438d3a58eba960998->enter($__internal_11fc3904cf89a49ba64ec1f2db6475d66ab7966496aa566438d3a58eba960998_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_11fc3904cf89a49ba64ec1f2db6475d66ab7966496aa566438d3a58eba960998->leave($__internal_11fc3904cf89a49ba64ec1f2db6475d66ab7966496aa566438d3a58eba960998_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_02a2e650512cbb3a70420269329dae2fada979b28045d390dee9dc393490afb3 = $this->env->getExtension("native_profiler");
        $__internal_02a2e650512cbb3a70420269329dae2fada979b28045d390dee9dc393490afb3->enter($__internal_02a2e650512cbb3a70420269329dae2fada979b28045d390dee9dc393490afb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_02a2e650512cbb3a70420269329dae2fada979b28045d390dee9dc393490afb3->leave($__internal_02a2e650512cbb3a70420269329dae2fada979b28045d390dee9dc393490afb3_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
