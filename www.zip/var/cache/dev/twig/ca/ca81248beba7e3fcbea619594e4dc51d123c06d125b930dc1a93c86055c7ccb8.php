<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_192c32ccb8a7c62e88a9e1d02689ab9ef5a8b7bbc73412649c4fe6d1ec4fd90a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f43ba91d528894d503b903fafc5dd7ea3945910da3857802d6a4058012f900fd = $this->env->getExtension("native_profiler");
        $__internal_f43ba91d528894d503b903fafc5dd7ea3945910da3857802d6a4058012f900fd->enter($__internal_f43ba91d528894d503b903fafc5dd7ea3945910da3857802d6a4058012f900fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_f43ba91d528894d503b903fafc5dd7ea3945910da3857802d6a4058012f900fd->leave($__internal_f43ba91d528894d503b903fafc5dd7ea3945910da3857802d6a4058012f900fd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */
