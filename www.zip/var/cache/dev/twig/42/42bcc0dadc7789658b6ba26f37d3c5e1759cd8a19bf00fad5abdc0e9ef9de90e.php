<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_92374ed706052fab7dd1a18e6756827664df734f214c334aabffb5eb87a34746 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b4cf4ac6ac02ac35a2f75464f117e8a0396843aa555ee223901c53ec4fd2c9d = $this->env->getExtension("native_profiler");
        $__internal_5b4cf4ac6ac02ac35a2f75464f117e8a0396843aa555ee223901c53ec4fd2c9d->enter($__internal_5b4cf4ac6ac02ac35a2f75464f117e8a0396843aa555ee223901c53ec4fd2c9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_5b4cf4ac6ac02ac35a2f75464f117e8a0396843aa555ee223901c53ec4fd2c9d->leave($__internal_5b4cf4ac6ac02ac35a2f75464f117e8a0396843aa555ee223901c53ec4fd2c9d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
