<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_ef33df78719087d0cea437a0bde7b0e06e387e5ab39b90bedc1f281179e71c0e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_247740f16860e5657c3d16a5d6175a05e30d18f518d25a89ded49c905d65e753 = $this->env->getExtension("native_profiler");
        $__internal_247740f16860e5657c3d16a5d6175a05e30d18f518d25a89ded49c905d65e753->enter($__internal_247740f16860e5657c3d16a5d6175a05e30d18f518d25a89ded49c905d65e753_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_247740f16860e5657c3d16a5d6175a05e30d18f518d25a89ded49c905d65e753->leave($__internal_247740f16860e5657c3d16a5d6175a05e30d18f518d25a89ded49c905d65e753_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
