<?php

/* @FOSUser/Registration/email.txt.twig */
class __TwigTemplate_0e466a362b9d87c630be385012d3e7d8936fe7ebc82a4a2a85c1a37b63607da6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_59d7081b1cdff13c2a1ac86986434f485b4e8485be7ff4204edea364b95985de = $this->env->getExtension("native_profiler");
        $__internal_59d7081b1cdff13c2a1ac86986434f485b4e8485be7ff4204edea364b95985de->enter($__internal_59d7081b1cdff13c2a1ac86986434f485b4e8485be7ff4204edea364b95985de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Registration/email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_59d7081b1cdff13c2a1ac86986434f485b4e8485be7ff4204edea364b95985de->leave($__internal_59d7081b1cdff13c2a1ac86986434f485b4e8485be7ff4204edea364b95985de_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_a9f82acb5f71f25cc721a0acd68b0ac7b6899d9d6fb53438321a33cd63f3ca4a = $this->env->getExtension("native_profiler");
        $__internal_a9f82acb5f71f25cc721a0acd68b0ac7b6899d9d6fb53438321a33cd63f3ca4a->enter($__internal_a9f82acb5f71f25cc721a0acd68b0ac7b6899d9d6fb53438321a33cd63f3ca4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_a9f82acb5f71f25cc721a0acd68b0ac7b6899d9d6fb53438321a33cd63f3ca4a->leave($__internal_a9f82acb5f71f25cc721a0acd68b0ac7b6899d9d6fb53438321a33cd63f3ca4a_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_5b0e028cc56ba5f2b8d2a08797c0b875b950d6258508da4b2e8d672860197969 = $this->env->getExtension("native_profiler");
        $__internal_5b0e028cc56ba5f2b8d2a08797c0b875b950d6258508da4b2e8d672860197969->enter($__internal_5b0e028cc56ba5f2b8d2a08797c0b875b950d6258508da4b2e8d672860197969_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_5b0e028cc56ba5f2b8d2a08797c0b875b950d6258508da4b2e8d672860197969->leave($__internal_5b0e028cc56ba5f2b8d2a08797c0b875b950d6258508da4b2e8d672860197969_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_2dd08563f5c3abd61510ce48a3e1221d8fce60b7c9896f464977cef90f08befd = $this->env->getExtension("native_profiler");
        $__internal_2dd08563f5c3abd61510ce48a3e1221d8fce60b7c9896f464977cef90f08befd->enter($__internal_2dd08563f5c3abd61510ce48a3e1221d8fce60b7c9896f464977cef90f08befd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_2dd08563f5c3abd61510ce48a3e1221d8fce60b7c9896f464977cef90f08befd->leave($__internal_2dd08563f5c3abd61510ce48a3e1221d8fce60b7c9896f464977cef90f08befd_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Registration/email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
