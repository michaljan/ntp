<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_c3c126ea41282f30f6e3b369d676938aebd6012473d599d816bde333779ae2ff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78eeb5a2bedd26b27fe527b570fc4f7e0dfc649d0c42358bba234298818e0da1 = $this->env->getExtension("native_profiler");
        $__internal_78eeb5a2bedd26b27fe527b570fc4f7e0dfc649d0c42358bba234298818e0da1->enter($__internal_78eeb5a2bedd26b27fe527b570fc4f7e0dfc649d0c42358bba234298818e0da1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_78eeb5a2bedd26b27fe527b570fc4f7e0dfc649d0c42358bba234298818e0da1->leave($__internal_78eeb5a2bedd26b27fe527b570fc4f7e0dfc649d0c42358bba234298818e0da1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */
