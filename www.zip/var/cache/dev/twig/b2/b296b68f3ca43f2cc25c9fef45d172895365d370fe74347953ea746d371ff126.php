<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_120d22132f43fa795f672891300909d6e47a7232940d2f6479004816259dd4f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2958d541a901a449f3d733b2e5ef3abc0b131fb9caf082825041999b5e120e62 = $this->env->getExtension("native_profiler");
        $__internal_2958d541a901a449f3d733b2e5ef3abc0b131fb9caf082825041999b5e120e62->enter($__internal_2958d541a901a449f3d733b2e5ef3abc0b131fb9caf082825041999b5e120e62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_2958d541a901a449f3d733b2e5ef3abc0b131fb9caf082825041999b5e120e62->leave($__internal_2958d541a901a449f3d733b2e5ef3abc0b131fb9caf082825041999b5e120e62_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
