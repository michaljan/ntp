<?php

/* @FOSUser/ChangePassword/changePassword.html.twig */
class __TwigTemplate_eb1990452b4f230b718cc9c496657b0ae3ec11f6290bfc575c76cf9a94351a9c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/ChangePassword/changePassword.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7af59634ccf47181722f11ec441c07640aaac896563694076d0926fbaf71bb32 = $this->env->getExtension("native_profiler");
        $__internal_7af59634ccf47181722f11ec441c07640aaac896563694076d0926fbaf71bb32->enter($__internal_7af59634ccf47181722f11ec441c07640aaac896563694076d0926fbaf71bb32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/ChangePassword/changePassword.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7af59634ccf47181722f11ec441c07640aaac896563694076d0926fbaf71bb32->leave($__internal_7af59634ccf47181722f11ec441c07640aaac896563694076d0926fbaf71bb32_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_e5818b584fea43aa2cbbe7769f1dbe467c48a5bea51f85a8922453d05144a2d2 = $this->env->getExtension("native_profiler");
        $__internal_e5818b584fea43aa2cbbe7769f1dbe467c48a5bea51f85a8922453d05144a2d2->enter($__internal_e5818b584fea43aa2cbbe7769f1dbe467c48a5bea51f85a8922453d05144a2d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:ChangePassword:changePassword_content.html.twig", "@FOSUser/ChangePassword/changePassword.html.twig", 4)->display($context);
        
        $__internal_e5818b584fea43aa2cbbe7769f1dbe467c48a5bea51f85a8922453d05144a2d2->leave($__internal_e5818b584fea43aa2cbbe7769f1dbe467c48a5bea51f85a8922453d05144a2d2_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/ChangePassword/changePassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:ChangePassword:changePassword_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
