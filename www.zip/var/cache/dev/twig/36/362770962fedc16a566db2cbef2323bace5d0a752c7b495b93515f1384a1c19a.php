<?php

/* @NTP/Reports/dashboard.html.twig */
class __TwigTemplate_3fd5e861ad3870b52b68d17a0469ee47f6e3bf033f240f534ba15b0cb5b82e79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "@NTP/Reports/dashboard.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'documentReady' => array($this, 'block_documentReady'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_728403276996d58ffe4ebd33be61a856934d969823979fe180c4a987f1e9f7f9 = $this->env->getExtension("native_profiler");
        $__internal_728403276996d58ffe4ebd33be61a856934d969823979fe180c4a987f1e9f7f9->enter($__internal_728403276996d58ffe4ebd33be61a856934d969823979fe180c4a987f1e9f7f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@NTP/Reports/dashboard.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_728403276996d58ffe4ebd33be61a856934d969823979fe180c4a987f1e9f7f9->leave($__internal_728403276996d58ffe4ebd33be61a856934d969823979fe180c4a987f1e9f7f9_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_fa490684b0f56a4b1297a4537d716e801b68e0623aaa628ae6432aea95e6bb50 = $this->env->getExtension("native_profiler");
        $__internal_fa490684b0f56a4b1297a4537d716e801b68e0623aaa628ae6432aea95e6bb50->enter($__internal_fa490684b0f56a4b1297a4537d716e801b68e0623aaa628ae6432aea95e6bb50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    ";
        if ((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report"))) {
            echo "            
        <br/>
        <div class=\"row\">
            <div class=\"col-md-4\">
                <div class=\"row\">
                    <div class=\"col-md-5\">
                        ";
            // line 9
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
            echo "
                        ";
            // line 10
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
                        ";
            // line 11
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "planDate", array()), 'row');
            echo "
                        ";
            // line 12
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
            echo "
                        ";
            // line 13
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
            echo "</div>
                    <div class=\"col-md-7\">
                    </div>
                </div>
                <br/>
                <table class=\"table table-bordered\">
                    <tr>
                        <td>Total duty time </td>
                        <td>";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "dutyTime", array()), "html", null, true);
            echo "</td>
                    </tr>
                    <tr>
                        <td>Total runs</td>
                        <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "runsCount", array()), "html", null, true);
            echo "</td>

                    </tr>
                    <tr>
                        <td>Driving distance km</td>
                        <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "distanceKm", array()), "html", null, true);
            echo "</td>

                    </tr>
                    <tr>
                        <td>Empty distance km</td>
                        <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "emptyDistKms", array()), "html", null, true);
            echo "</td>

                    </tr>
                    <tr>
                        <td>Time utilisation %</td>
                        <td>";
            // line 40
            echo twig_escape_filter($this->env, twig_round($this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "timeUtil", array()), 2, "floor"), "html", null, true);
            echo "</td>
                    </tr>
                    <tr>
                        <td>Avarge duty time</td>
                        <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "avgDutyTime", array()), "html", null, true);
            echo "</td>
                    </tr>
                    <tr>
                        <td>Avarge distance km</td>
                        <td>";
            // line 48
            echo twig_escape_filter($this->env, twig_round($this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "avgDistance", array())), "html", null, true);
            echo "</td>
                    </tr>
                    <tr>
                        <td>Avarge empty distance km</td>
                        <td>";
            // line 52
            echo twig_escape_filter($this->env, twig_round($this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "avgEmptyDist", array())), "html", null, true);
            echo "</td>
                    </tr>
                </table>
            </div>
            <div class=\"col-md-4\">
                <div class=\"caption\"><h4>Runs per site</h4></div>
                <div id=\"bar-drivers\" style=\"height: 250px;\"></div>
                <div class=\"caption\"><h4>Avarge drive time per site</h4></div>
                <div id=\"bar-timePerSite\" style=\"height: 250px;\"></div>
            </div>
            <div class=\"col-md-4\">
                <div class=\"caption\"><h4>Time utilisation per site</h4></div>
                <div id=\"bar-avgTime\" style=\"height: 250px;\"></div>
            </div>
        </div>
    ";
        } else {
            // line 68
            echo "        <div class=\"row\">
            <div class=\"col-md-3\">
                ";
            // line 70
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
            echo "
                ";
            // line 71
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
            echo "
                ";
            // line 72
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "planDate", array()), 'row');
            echo "
                ";
            // line 73
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "submit", array()), 'row');
            echo "
                ";
            // line 74
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
            echo "</div>
            <br/>
            <div class=\"col-md9\">
                 ";
            // line 77
            if ((isset($context["message"]) ? $context["message"] : $this->getContext($context, "message"))) {
                // line 78
                echo "                     <h5><b>";
                echo twig_escape_filter($this->env, (isset($context["message"]) ? $context["message"] : $this->getContext($context, "message")), "html", null, true);
                echo "</b></h5>
                 ";
            }
            // line 79
            echo "    

            </div>
        </div>
    ";
        }
        
        $__internal_fa490684b0f56a4b1297a4537d716e801b68e0623aaa628ae6432aea95e6bb50->leave($__internal_fa490684b0f56a4b1297a4537d716e801b68e0623aaa628ae6432aea95e6bb50_prof);

    }

    // line 85
    public function block_documentReady($context, array $blocks = array())
    {
        $__internal_e56dec7930fda978a36af783b50dd693c4bd668a6d94379a7e99b6fd001ecadc = $this->env->getExtension("native_profiler");
        $__internal_e56dec7930fda978a36af783b50dd693c4bd668a6d94379a7e99b6fd001ecadc->enter($__internal_e56dec7930fda978a36af783b50dd693c4bd668a6d94379a7e99b6fd001ecadc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "documentReady"));

        // line 86
        echo "    ";
        if ((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report"))) {
            // line 87
            echo "        var paragonRuns = ";
            echo $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "graphRuns", array());
            echo ";
        var graphAvgTime = ";
            // line 88
            echo $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "graphAvgTime", array());
            echo ";
        var graphTimePerSite = ";
            // line 89
            echo $this->getAttribute((isset($context["report"]) ? $context["report"] : $this->getContext($context, "report")), "graphTimePerSite", array());
            echo ";
    ";
        }
        // line 91
        echo "    Morris.Bar({
    element: 'bar-drivers',
    hideHover: 'false',
    data: paragonRuns,
    xkey: 'y',
    ykeys: ['a'],
    labels: ['Runs'],
    gridTextSize: '10',
    stacked: true,
    resize: true,
    xLabelAngle: 35
    });

    Morris.Bar({
    element: 'bar-avgTime',
    hideHover: 'false',
    data: graphAvgTime,
    xkey: 'y',
    ykeys: ['a'],
    labels: ['Avarge time'],
    gridTextSize: '10',
    stacked: true,
    resize: true,
    xLabelAngle: 35,
    ymax: 100
    });
    
    Morris.Bar({
    element: 'bar-timePerSite',
    hideHover: 'false',
    data: graphTimePerSite,
    xkey: 'y',
    ykeys: ['a'],
    labels: ['Avarge time'],
    gridTextSize: '10',
    stacked: true,
    resize: true,
    xLabelAngle: 35,
    });
";
        
        $__internal_e56dec7930fda978a36af783b50dd693c4bd668a6d94379a7e99b6fd001ecadc->leave($__internal_e56dec7930fda978a36af783b50dd693c4bd668a6d94379a7e99b6fd001ecadc_prof);

    }

    public function getTemplateName()
    {
        return "@NTP/Reports/dashboard.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  218 => 91,  213 => 89,  209 => 88,  204 => 87,  201 => 86,  195 => 85,  183 => 79,  177 => 78,  175 => 77,  169 => 74,  165 => 73,  161 => 72,  157 => 71,  153 => 70,  149 => 68,  130 => 52,  123 => 48,  116 => 44,  109 => 40,  101 => 35,  93 => 30,  85 => 25,  78 => 21,  67 => 13,  63 => 12,  59 => 11,  55 => 10,  51 => 9,  41 => 3,  35 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     {% if report %}            */
/*         <br/>*/
/*         <div class="row">*/
/*             <div class="col-md-4">*/
/*                 <div class="row">*/
/*                     <div class="col-md-5">*/
/*                         {{ form_start(form) }}*/
/*                         {{ form_errors(form) }}*/
/*                         {{ form_row(form.planDate) }}*/
/*                         {{ form_row(form.submit) }}*/
/*                         {{ form_end(form) }}</div>*/
/*                     <div class="col-md-7">*/
/*                     </div>*/
/*                 </div>*/
/*                 <br/>*/
/*                 <table class="table table-bordered">*/
/*                     <tr>*/
/*                         <td>Total duty time </td>*/
/*                         <td>{{ report.dutyTime }}</td>*/
/*                     </tr>*/
/*                     <tr>*/
/*                         <td>Total runs</td>*/
/*                         <td>{{ report.runsCount }}</td>*/
/* */
/*                     </tr>*/
/*                     <tr>*/
/*                         <td>Driving distance km</td>*/
/*                         <td>{{ report.distanceKm }}</td>*/
/* */
/*                     </tr>*/
/*                     <tr>*/
/*                         <td>Empty distance km</td>*/
/*                         <td>{{ report.emptyDistKms}}</td>*/
/* */
/*                     </tr>*/
/*                     <tr>*/
/*                         <td>Time utilisation %</td>*/
/*                         <td>{{ report.timeUtil|round(2, 'floor')}}</td>*/
/*                     </tr>*/
/*                     <tr>*/
/*                         <td>Avarge duty time</td>*/
/*                         <td>{{ report.avgDutyTime }}</td>*/
/*                     </tr>*/
/*                     <tr>*/
/*                         <td>Avarge distance km</td>*/
/*                         <td>{{ report.avgDistance|round }}</td>*/
/*                     </tr>*/
/*                     <tr>*/
/*                         <td>Avarge empty distance km</td>*/
/*                         <td>{{ report.avgEmptyDist|round }}</td>*/
/*                     </tr>*/
/*                 </table>*/
/*             </div>*/
/*             <div class="col-md-4">*/
/*                 <div class="caption"><h4>Runs per site</h4></div>*/
/*                 <div id="bar-drivers" style="height: 250px;"></div>*/
/*                 <div class="caption"><h4>Avarge drive time per site</h4></div>*/
/*                 <div id="bar-timePerSite" style="height: 250px;"></div>*/
/*             </div>*/
/*             <div class="col-md-4">*/
/*                 <div class="caption"><h4>Time utilisation per site</h4></div>*/
/*                 <div id="bar-avgTime" style="height: 250px;"></div>*/
/*             </div>*/
/*         </div>*/
/*     {% else %}*/
/*         <div class="row">*/
/*             <div class="col-md-3">*/
/*                 {{ form_start(form) }}*/
/*                 {{ form_errors(form) }}*/
/*                 {{ form_row(form.planDate) }}*/
/*                 {{ form_row(form.submit) }}*/
/*                 {{ form_end(form) }}</div>*/
/*             <br/>*/
/*             <div class="col-md9">*/
/*                  {% if message %}*/
/*                      <h5><b>{{ message }}</b></h5>*/
/*                  {% endif %}    */
/* */
/*             </div>*/
/*         </div>*/
/*     {% endif %}*/
/* {% endblock %}*/
/* {% block documentReady %}*/
/*     {% if report %}*/
/*         var paragonRuns = {{ report.graphRuns | raw }};*/
/*         var graphAvgTime = {{ report.graphAvgTime | raw }};*/
/*         var graphTimePerSite = {{ report.graphTimePerSite | raw }};*/
/*     {% endif %}*/
/*     Morris.Bar({*/
/*     element: 'bar-drivers',*/
/*     hideHover: 'false',*/
/*     data: paragonRuns,*/
/*     xkey: 'y',*/
/*     ykeys: ['a'],*/
/*     labels: ['Runs'],*/
/*     gridTextSize: '10',*/
/*     stacked: true,*/
/*     resize: true,*/
/*     xLabelAngle: 35*/
/*     });*/
/* */
/*     Morris.Bar({*/
/*     element: 'bar-avgTime',*/
/*     hideHover: 'false',*/
/*     data: graphAvgTime,*/
/*     xkey: 'y',*/
/*     ykeys: ['a'],*/
/*     labels: ['Avarge time'],*/
/*     gridTextSize: '10',*/
/*     stacked: true,*/
/*     resize: true,*/
/*     xLabelAngle: 35,*/
/*     ymax: 100*/
/*     });*/
/*     */
/*     Morris.Bar({*/
/*     element: 'bar-timePerSite',*/
/*     hideHover: 'false',*/
/*     data: graphTimePerSite,*/
/*     xkey: 'y',*/
/*     ykeys: ['a'],*/
/*     labels: ['Avarge time'],*/
/*     gridTextSize: '10',*/
/*     stacked: true,*/
/*     resize: true,*/
/*     xLabelAngle: 35,*/
/*     });*/
/* {% endblock documentReady %}*/
/* */
