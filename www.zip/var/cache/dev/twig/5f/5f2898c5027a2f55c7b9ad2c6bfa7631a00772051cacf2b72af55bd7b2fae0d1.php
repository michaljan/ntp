<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_db8e27add756eab55c068afe56cc3d9d5e43743e2a40619b47a0386d37aaca60 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_80b8d4972a65e615152ada13e1d6f8a944e9bbb6ddb473c904b1e7b39e950515 = $this->env->getExtension("native_profiler");
        $__internal_80b8d4972a65e615152ada13e1d6f8a944e9bbb6ddb473c904b1e7b39e950515->enter($__internal_80b8d4972a65e615152ada13e1d6f8a944e9bbb6ddb473c904b1e7b39e950515_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_80b8d4972a65e615152ada13e1d6f8a944e9bbb6ddb473c904b1e7b39e950515->leave($__internal_80b8d4972a65e615152ada13e1d6f8a944e9bbb6ddb473c904b1e7b39e950515_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
