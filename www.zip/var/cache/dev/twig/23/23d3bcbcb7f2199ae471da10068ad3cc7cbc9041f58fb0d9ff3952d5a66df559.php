<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_af20db26ad2a569708e88290ece0b1d346e8b4912e46ef62b8ad7d63e91b5cfd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8754d3cc7d7d1231c9f5ae3df271a5180f1476d6b7751369ea50314f20d4e34 = $this->env->getExtension("native_profiler");
        $__internal_b8754d3cc7d7d1231c9f5ae3df271a5180f1476d6b7751369ea50314f20d4e34->enter($__internal_b8754d3cc7d7d1231c9f5ae3df271a5180f1476d6b7751369ea50314f20d4e34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b8754d3cc7d7d1231c9f5ae3df271a5180f1476d6b7751369ea50314f20d4e34->leave($__internal_b8754d3cc7d7d1231c9f5ae3df271a5180f1476d6b7751369ea50314f20d4e34_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f7ecfe5f7d434d9f5c60f1a83af9d2930cb49e9b6764bf66e7a9545c997ad681 = $this->env->getExtension("native_profiler");
        $__internal_f7ecfe5f7d434d9f5c60f1a83af9d2930cb49e9b6764bf66e7a9545c997ad681->enter($__internal_f7ecfe5f7d434d9f5c60f1a83af9d2930cb49e9b6764bf66e7a9545c997ad681_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_f7ecfe5f7d434d9f5c60f1a83af9d2930cb49e9b6764bf66e7a9545c997ad681->leave($__internal_f7ecfe5f7d434d9f5c60f1a83af9d2930cb49e9b6764bf66e7a9545c997ad681_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
