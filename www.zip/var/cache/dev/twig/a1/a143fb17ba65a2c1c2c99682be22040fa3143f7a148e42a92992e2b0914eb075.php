<?php

/* @NTP/File/file_processed.html.twig */
class __TwigTemplate_397090a4ee662e60453682fa290259edbbae3f3d574d28be7b0badb5e7cba4a6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "@NTP/File/file_processed.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a17bba8f60306d6f538ec0ed364a00c44f712a73d72c7c846447cbf5c2f47348 = $this->env->getExtension("native_profiler");
        $__internal_a17bba8f60306d6f538ec0ed364a00c44f712a73d72c7c846447cbf5c2f47348->enter($__internal_a17bba8f60306d6f538ec0ed364a00c44f712a73d72c7c846447cbf5c2f47348_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@NTP/File/file_processed.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a17bba8f60306d6f538ec0ed364a00c44f712a73d72c7c846447cbf5c2f47348->leave($__internal_a17bba8f60306d6f538ec0ed364a00c44f712a73d72c7c846447cbf5c2f47348_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_6e842a5d9835156f2e7495fba308d69015f1809a02e2f3304e291663f0e6f171 = $this->env->getExtension("native_profiler");
        $__internal_6e842a5d9835156f2e7495fba308d69015f1809a02e2f3304e291663f0e6f171->enter($__internal_6e842a5d9835156f2e7495fba308d69015f1809a02e2f3304e291663f0e6f171_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    
    ";
        // line 4
        if (((isset($context["message"]) ? $context["message"] : $this->getContext($context, "message")) == null)) {
            // line 5
            echo "    <p>File processed succefuly</p>
    <br/>
    <p>Errors: ";
            // line 7
            echo twig_escape_filter($this->env, (isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors")), "html", null, true);
            echo "</p> <br/>
    <p>Sucess: ";
            // line 8
            echo twig_escape_filter($this->env, (isset($context["success"]) ? $context["success"] : $this->getContext($context, "success")), "html", null, true);
            echo "</p> <br/>
    <table class=\"table table-striped\">
    ";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["exceptionsArray"]) ? $context["exceptionsArray"] : $this->getContext($context, "exceptionsArray")));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 11
                echo "        <tr>
            <td> ";
                // line 12
                echo twig_escape_filter($this->env, $context["item"], "html", null, true);
                echo " </td><br/>
        </tr>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 15
            echo "    ";
        } else {
            // line 16
            echo "        <p>";
            echo twig_escape_filter($this->env, (isset($context["message"]) ? $context["message"] : $this->getContext($context, "message")), "html", null, true);
            echo "</p>
        <br/>
         <a href=\"";
            // line 18
            echo $this->env->getExtension('routing')->getPath("file_display");
            echo "\">Return to display page</a>
    ";
        }
        // line 20
        echo "    </table>
    
    
";
        
        $__internal_6e842a5d9835156f2e7495fba308d69015f1809a02e2f3304e291663f0e6f171->leave($__internal_6e842a5d9835156f2e7495fba308d69015f1809a02e2f3304e291663f0e6f171_prof);

    }

    public function getTemplateName()
    {
        return "@NTP/File/file_processed.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 20,  83 => 18,  77 => 16,  74 => 15,  65 => 12,  62 => 11,  58 => 10,  53 => 8,  49 => 7,  45 => 5,  43 => 4,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     */
/*     {% if message==null %}*/
/*     <p>File processed succefuly</p>*/
/*     <br/>*/
/*     <p>Errors: {{ errors }}</p> <br/>*/
/*     <p>Sucess: {{ success }}</p> <br/>*/
/*     <table class="table table-striped">*/
/*     {% for item in exceptionsArray %}*/
/*         <tr>*/
/*             <td> {{ item }} </td><br/>*/
/*         </tr>*/
/*     {% endfor %}*/
/*     {% else %}*/
/*         <p>{{ message }}</p>*/
/*         <br/>*/
/*          <a href="{{ path('file_display') }}">Return to display page</a>*/
/*     {% endif %}*/
/*     </table>*/
/*     */
/*     */
/* {% endblock %}*/
/* */
