<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_e709fc3aba3fe88a29d2a71783f4fe00c10cf7e9adc1e8b1f14ebf410f344f1b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6178ccf7fd188e7b012de747bfcd60d11e2f4d2b3cd18792a79fff2331329639 = $this->env->getExtension("native_profiler");
        $__internal_6178ccf7fd188e7b012de747bfcd60d11e2f4d2b3cd18792a79fff2331329639->enter($__internal_6178ccf7fd188e7b012de747bfcd60d11e2f4d2b3cd18792a79fff2331329639_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_6178ccf7fd188e7b012de747bfcd60d11e2f4d2b3cd18792a79fff2331329639->leave($__internal_6178ccf7fd188e7b012de747bfcd60d11e2f4d2b3cd18792a79fff2331329639_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
