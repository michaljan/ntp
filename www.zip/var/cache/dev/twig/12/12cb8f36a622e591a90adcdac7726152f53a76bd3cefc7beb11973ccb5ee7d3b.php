<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_288755bb05a765cf91fb220b46ccac88997b293167681c344a3b30e7f141799b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7974f9f31237f9319f2686cb3e2c7aef1a7f248b3e7df2daca5bc4623e9a9413 = $this->env->getExtension("native_profiler");
        $__internal_7974f9f31237f9319f2686cb3e2c7aef1a7f248b3e7df2daca5bc4623e9a9413->enter($__internal_7974f9f31237f9319f2686cb3e2c7aef1a7f248b3e7df2daca5bc4623e9a9413_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_7974f9f31237f9319f2686cb3e2c7aef1a7f248b3e7df2daca5bc4623e9a9413->leave($__internal_7974f9f31237f9319f2686cb3e2c7aef1a7f248b3e7df2daca5bc4623e9a9413_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
