<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_38c208b4ac0991878607d57e2f374a580809a6003496877ad8a55b21381c0b48 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0bdc8da3f5fc140dd9b95ad85bf05fa94067ba2a8476ae8f42558ce7b223decf = $this->env->getExtension("native_profiler");
        $__internal_0bdc8da3f5fc140dd9b95ad85bf05fa94067ba2a8476ae8f42558ce7b223decf->enter($__internal_0bdc8da3f5fc140dd9b95ad85bf05fa94067ba2a8476ae8f42558ce7b223decf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0bdc8da3f5fc140dd9b95ad85bf05fa94067ba2a8476ae8f42558ce7b223decf->leave($__internal_0bdc8da3f5fc140dd9b95ad85bf05fa94067ba2a8476ae8f42558ce7b223decf_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_806957a6d73801047c3c1fc1221a6a4d27b521bfb3fb52fa12f3218963006c3f = $this->env->getExtension("native_profiler");
        $__internal_806957a6d73801047c3c1fc1221a6a4d27b521bfb3fb52fa12f3218963006c3f->enter($__internal_806957a6d73801047c3c1fc1221a6a4d27b521bfb3fb52fa12f3218963006c3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_806957a6d73801047c3c1fc1221a6a4d27b521bfb3fb52fa12f3218963006c3f->leave($__internal_806957a6d73801047c3c1fc1221a6a4d27b521bfb3fb52fa12f3218963006c3f_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
