<?php

/* @NTP/Forms/upload_form.html.twig */
class __TwigTemplate_0061ff6e9a4b0cdedc41933a3542e8f231c9bc6b7318b689171d62d1b8fb4469 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "@NTP/Forms/upload_form.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b67162a96eece694ac484fbbec273e16a8db5c5970d10d4f6c204a0214bfcac4 = $this->env->getExtension("native_profiler");
        $__internal_b67162a96eece694ac484fbbec273e16a8db5c5970d10d4f6c204a0214bfcac4->enter($__internal_b67162a96eece694ac484fbbec273e16a8db5c5970d10d4f6c204a0214bfcac4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@NTP/Forms/upload_form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b67162a96eece694ac484fbbec273e16a8db5c5970d10d4f6c204a0214bfcac4->leave($__internal_b67162a96eece694ac484fbbec273e16a8db5c5970d10d4f6c204a0214bfcac4_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_e01a28f81699d47fb962759bca9814e95533fd3e798f99ae6dda1ea63aee3429 = $this->env->getExtension("native_profiler");
        $__internal_e01a28f81699d47fb962759bca9814e95533fd3e798f99ae6dda1ea63aee3429->enter($__internal_e01a28f81699d47fb962759bca9814e95533fd3e798f99ae6dda1ea63aee3429_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <div class=\"row\">
        <div class=\"col-md-5\"></div>
        <div class=\"col-md-2\">
            ";
        // line 6
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
            ";
        // line 7
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "

            ";
        // line 9
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "file", array()), 'row');
        echo "
            <br/>
            ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "planDate", array()), 'row');
        echo "
            <br/>
            ";
        // line 13
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
        </div>
        <div class=\"col-md-5\"></div>
    </div>
";
        
        $__internal_e01a28f81699d47fb962759bca9814e95533fd3e798f99ae6dda1ea63aee3429->leave($__internal_e01a28f81699d47fb962759bca9814e95533fd3e798f99ae6dda1ea63aee3429_prof);

    }

    public function getTemplateName()
    {
        return "@NTP/Forms/upload_form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 13,  59 => 11,  54 => 9,  49 => 7,  45 => 6,  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <div class="row">*/
/*         <div class="col-md-5"></div>*/
/*         <div class="col-md-2">*/
/*             {{ form_start(form) }}*/
/*             {{ form_errors(form) }}*/
/* */
/*             {{ form_row(form.file) }}*/
/*             <br/>*/
/*             {{ form_row(form.planDate) }}*/
/*             <br/>*/
/*             {{ form_end(form) }}*/
/*         </div>*/
/*         <div class="col-md-5"></div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
