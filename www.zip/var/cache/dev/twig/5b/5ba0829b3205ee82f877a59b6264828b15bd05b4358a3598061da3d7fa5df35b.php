<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_46de47275cdd03563970b92fe7f7112f79136e1563768ab091556ffd0df767f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af03cf642492a16d221e87f4fa34a42eff3ec65aa8158e52d29bd7811a30c5c8 = $this->env->getExtension("native_profiler");
        $__internal_af03cf642492a16d221e87f4fa34a42eff3ec65aa8158e52d29bd7811a30c5c8->enter($__internal_af03cf642492a16d221e87f4fa34a42eff3ec65aa8158e52d29bd7811a30c5c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_af03cf642492a16d221e87f4fa34a42eff3ec65aa8158e52d29bd7811a30c5c8->leave($__internal_af03cf642492a16d221e87f4fa34a42eff3ec65aa8158e52d29bd7811a30c5c8_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_55a30b7fa80e62b8284b32b2925168631feaaf7b3826ae5628bed5bde46667b6 = $this->env->getExtension("native_profiler");
        $__internal_55a30b7fa80e62b8284b32b2925168631feaaf7b3826ae5628bed5bde46667b6->enter($__internal_55a30b7fa80e62b8284b32b2925168631feaaf7b3826ae5628bed5bde46667b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_55a30b7fa80e62b8284b32b2925168631feaaf7b3826ae5628bed5bde46667b6->leave($__internal_55a30b7fa80e62b8284b32b2925168631feaaf7b3826ae5628bed5bde46667b6_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
