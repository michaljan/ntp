<?php

/* NTPBundle:Menu:knp_menu.html.twig */
class __TwigTemplate_46c5c382b688178c36862046b6a77d6687bba3119341c0ec8057ba525bb864b0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("knp_menu.html.twig", "NTPBundle:Menu:knp_menu.html.twig", 1);
        $this->blocks = array(
            'item' => array($this, 'block_item'),
            'dividerElement' => array($this, 'block_dividerElement'),
            'dropdownElement' => array($this, 'block_dropdownElement'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "knp_menu.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1febc10ae6d52e43778090e09177e80ba771a5b976f3f77c834baf68a0ec193d = $this->env->getExtension("native_profiler");
        $__internal_1febc10ae6d52e43778090e09177e80ba771a5b976f3f77c834baf68a0ec193d->enter($__internal_1febc10ae6d52e43778090e09177e80ba771a5b976f3f77c834baf68a0ec193d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NTPBundle:Menu:knp_menu.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1febc10ae6d52e43778090e09177e80ba771a5b976f3f77c834baf68a0ec193d->leave($__internal_1febc10ae6d52e43778090e09177e80ba771a5b976f3f77c834baf68a0ec193d_prof);

    }

    // line 3
    public function block_item($context, array $blocks = array())
    {
        $__internal_9722b4c81e794d882c18ea5553be402d2367eeea04afd18056d1c4de5d9a8335 = $this->env->getExtension("native_profiler");
        $__internal_9722b4c81e794d882c18ea5553be402d2367eeea04afd18056d1c4de5d9a8335->enter($__internal_9722b4c81e794d882c18ea5553be402d2367eeea04afd18056d1c4de5d9a8335_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "item"));

        // line 4
        $context["macros"] = $this->loadTemplate("knp_menu.html.twig", "NTPBundle:Menu:knp_menu.html.twig", 4);
        // line 5
        if ($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "displayed", array())) {
            // line 6
            $context["attributes"] = $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "attributes", array());
            // line 7
            $context["is_dropdown"] = (($this->getAttribute((isset($context["attributes"]) ? $context["attributes"] : null), "dropdown", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute((isset($context["attributes"]) ? $context["attributes"] : null), "dropdown", array()), false)) : (false));
            // line 8
            $context["divider_prepend"] = (($this->getAttribute((isset($context["attributes"]) ? $context["attributes"] : null), "divider_prepend", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute((isset($context["attributes"]) ? $context["attributes"] : null), "divider_prepend", array()), false)) : (false));
            // line 9
            $context["divider_append"] = (($this->getAttribute((isset($context["attributes"]) ? $context["attributes"] : null), "divider_append", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute((isset($context["attributes"]) ? $context["attributes"] : null), "divider_append", array()), false)) : (false));
            // line 10
            echo "
";
            // line 12
            $context["attributes"] = twig_array_merge((isset($context["attributes"]) ? $context["attributes"] : $this->getContext($context, "attributes")), array("dropdown" => null, "divider_prepend" => null, "divider_append" => null));
            // line 14
            if ((isset($context["divider_prepend"]) ? $context["divider_prepend"] : $this->getContext($context, "divider_prepend"))) {
                // line 15
                echo "        ";
                $this->displayBlock("dividerElement", $context, $blocks);
            }
            // line 17
            echo "
";
            // line 19
            $context["classes"] = (( !twig_test_empty($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "attribute", array(0 => "class"), "method"))) ? (array(0 => $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "attribute", array(0 => "class"), "method"))) : (array()));
            // line 20
            if ($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "current", array())) {
                // line 21
                $context["classes"] = twig_array_merge((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")), array(0 => $this->getAttribute((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")), "currentClass", array())));
            } elseif ($this->getAttribute(            // line 22
(isset($context["matcher"]) ? $context["matcher"] : $this->getContext($context, "matcher")), "isAncestor", array(0 => (isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), 1 => $this->getAttribute((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")), "depth", array())), "method")) {
                // line 23
                $context["classes"] = twig_array_merge((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")), array(0 => $this->getAttribute((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")), "ancestorClass", array())));
            }
            // line 25
            if ($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "actsLikeFirst", array())) {
                // line 26
                $context["classes"] = twig_array_merge((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")), array(0 => $this->getAttribute((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")), "firstClass", array())));
            }
            // line 28
            if ($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "actsLikeLast", array())) {
                // line 29
                $context["classes"] = twig_array_merge((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")), array(0 => $this->getAttribute((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")), "lastClass", array())));
            }
            // line 31
            echo "
";
            // line 33
            $context["childrenClasses"] = (( !twig_test_empty($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "childrenAttribute", array(0 => "class"), "method"))) ? (array(0 => $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "childrenAttribute", array(0 => "class"), "method"))) : (array()));
            // line 34
            $context["childrenClasses"] = twig_array_merge((isset($context["childrenClasses"]) ? $context["childrenClasses"] : $this->getContext($context, "childrenClasses")), array(0 => ("menu_level_" . $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "level", array()))));
            // line 35
            echo "
";
            // line 37
            if ((isset($context["is_dropdown"]) ? $context["is_dropdown"] : $this->getContext($context, "is_dropdown"))) {
                // line 38
                $context["classes"] = twig_array_merge((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")), array(0 => "dropdown"));
                // line 39
                $context["childrenClasses"] = twig_array_merge((isset($context["childrenClasses"]) ? $context["childrenClasses"] : $this->getContext($context, "childrenClasses")), array(0 => "dropdown-menu"));
            }
            // line 41
            echo "
";
            // line 43
            if ( !twig_test_empty((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")))) {
                // line 44
                $context["attributes"] = twig_array_merge((isset($context["attributes"]) ? $context["attributes"] : $this->getContext($context, "attributes")), array("class" => twig_join_filter((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")), " ")));
            }
            // line 46
            $context["listAttributes"] = twig_array_merge($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "childrenAttributes", array()), array("class" => twig_join_filter((isset($context["childrenClasses"]) ? $context["childrenClasses"] : $this->getContext($context, "childrenClasses")), " ")));
            // line 47
            echo "
";
            // line 49
            echo "    <li";
            echo $context["macros"]->getattributes((isset($context["attributes"]) ? $context["attributes"] : $this->getContext($context, "attributes")));
            echo ">";
            // line 50
            if ((isset($context["is_dropdown"]) ? $context["is_dropdown"] : $this->getContext($context, "is_dropdown"))) {
                // line 51
                echo "            ";
                $this->displayBlock("dropdownElement", $context, $blocks);
            } elseif (( !twig_test_empty($this->getAttribute(            // line 52
(isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "uri", array())) && ( !$this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "current", array()) || $this->getAttribute((isset($context["options"]) ? $context["options"] : $this->getContext($context, "options")), "currentAsLink", array())))) {
                // line 53
                echo "            ";
                $this->displayBlock("linkElement", $context, $blocks);
            } else {
                // line 55
                echo "            ";
                $this->displayBlock("spanElement", $context, $blocks);
            }
            // line 58
            echo "        ";
            $this->displayBlock("list", $context, $blocks);
            echo "
    </li>";
            // line 61
            if ((isset($context["divider_append"]) ? $context["divider_append"] : $this->getContext($context, "divider_append"))) {
                // line 62
                echo "        ";
                $this->displayBlock("dividerElement", $context, $blocks);
            }
        }
        
        $__internal_9722b4c81e794d882c18ea5553be402d2367eeea04afd18056d1c4de5d9a8335->leave($__internal_9722b4c81e794d882c18ea5553be402d2367eeea04afd18056d1c4de5d9a8335_prof);

    }

    // line 67
    public function block_dividerElement($context, array $blocks = array())
    {
        $__internal_f7a8d5c88455e9fe9f38d46e7cfe566eabea57fa291286164b55917bc00cc93e = $this->env->getExtension("native_profiler");
        $__internal_f7a8d5c88455e9fe9f38d46e7cfe566eabea57fa291286164b55917bc00cc93e->enter($__internal_f7a8d5c88455e9fe9f38d46e7cfe566eabea57fa291286164b55917bc00cc93e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dividerElement"));

        // line 68
        if (($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "level", array()) == 1)) {
            // line 69
            echo "    <li class=\"divider-vertical\"></li>
";
        } else {
            // line 71
            echo "    <li class=\"divider\"></li>
";
        }
        
        $__internal_f7a8d5c88455e9fe9f38d46e7cfe566eabea57fa291286164b55917bc00cc93e->leave($__internal_f7a8d5c88455e9fe9f38d46e7cfe566eabea57fa291286164b55917bc00cc93e_prof);

    }

    // line 75
    public function block_dropdownElement($context, array $blocks = array())
    {
        $__internal_272541c193396505a1eb23aeb5ae074c9cd2dea72d9599b13994b2595c0379a0 = $this->env->getExtension("native_profiler");
        $__internal_272541c193396505a1eb23aeb5ae074c9cd2dea72d9599b13994b2595c0379a0->enter($__internal_272541c193396505a1eb23aeb5ae074c9cd2dea72d9599b13994b2595c0379a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "dropdownElement"));

        // line 76
        $context["classes"] = (( !twig_test_empty($this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "linkAttribute", array(0 => "class"), "method"))) ? (array(0 => $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "linkAttribute", array(0 => "class"), "method"))) : (array()));
        // line 77
        $context["classes"] = twig_array_merge((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")), array(0 => "dropdown-toggle"));
        // line 78
        $context["attributes"] = $this->getAttribute((isset($context["item"]) ? $context["item"] : $this->getContext($context, "item")), "linkAttributes", array());
        // line 79
        $context["attributes"] = twig_array_merge((isset($context["attributes"]) ? $context["attributes"] : $this->getContext($context, "attributes")), array("class" => twig_join_filter((isset($context["classes"]) ? $context["classes"] : $this->getContext($context, "classes")), " ")));
        // line 80
        $context["attributes"] = twig_array_merge((isset($context["attributes"]) ? $context["attributes"] : $this->getContext($context, "attributes")), array("data-toggle" => "dropdown"));
        // line 81
        echo "    <a href=\"#\"";
        echo $this->getAttribute((isset($context["macros"]) ? $context["macros"] : $this->getContext($context, "macros")), "attributes", array(0 => (isset($context["attributes"]) ? $context["attributes"] : $this->getContext($context, "attributes"))), "method");
        echo ">";
        $this->displayBlock("label", $context, $blocks);
        echo " <b class=\"caret\"></b></a>
";
        
        $__internal_272541c193396505a1eb23aeb5ae074c9cd2dea72d9599b13994b2595c0379a0->leave($__internal_272541c193396505a1eb23aeb5ae074c9cd2dea72d9599b13994b2595c0379a0_prof);

    }

    public function getTemplateName()
    {
        return "NTPBundle:Menu:knp_menu.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  192 => 81,  190 => 80,  188 => 79,  186 => 78,  184 => 77,  182 => 76,  176 => 75,  167 => 71,  163 => 69,  161 => 68,  155 => 67,  145 => 62,  143 => 61,  138 => 58,  134 => 55,  130 => 53,  128 => 52,  125 => 51,  123 => 50,  119 => 49,  116 => 47,  114 => 46,  111 => 44,  109 => 43,  106 => 41,  103 => 39,  101 => 38,  99 => 37,  96 => 35,  94 => 34,  92 => 33,  89 => 31,  86 => 29,  84 => 28,  81 => 26,  79 => 25,  76 => 23,  74 => 22,  72 => 21,  70 => 20,  68 => 19,  65 => 17,  61 => 15,  59 => 14,  57 => 12,  54 => 10,  52 => 9,  50 => 8,  48 => 7,  46 => 6,  44 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'knp_menu.html.twig' %}*/
/* */
/* {% block item %}*/
/* {% import "knp_menu.html.twig" as macros %}*/
/* {% if item.displayed %}*/
/*     {%- set attributes = item.attributes %}*/
/*     {%- set is_dropdown = attributes.dropdown|default(false) %}*/
/*     {%- set divider_prepend = attributes.divider_prepend|default(false) %}*/
/*     {%- set divider_append = attributes.divider_append|default(false) %}*/
/* */
/* {# unset bootstrap specific attributes #}*/
/*     {%- set attributes = attributes|merge({'dropdown': null, 'divider_prepend': null, 'divider_append': null }) %}*/
/* */
/*     {%- if divider_prepend %}*/
/*         {{ block('dividerElement') }}*/
/*     {%- endif %}*/
/* */
/* {# building the class of the item #}*/
/*     {%- set classes = item.attribute('class') is not empty ? [item.attribute('class')] : [] %}*/
/*     {%- if item.current %}*/
/*         {%- set classes = classes|merge([options.currentClass]) %}*/
/*     {%- elseif matcher.isAncestor(item, options.depth) %}*/
/*         {%- set classes = classes|merge([options.ancestorClass]) %}*/
/*     {%- endif %}*/
/*     {%- if item.actsLikeFirst %}*/
/*         {%- set classes = classes|merge([options.firstClass]) %}*/
/*     {%- endif %}*/
/*     {%- if item.actsLikeLast %}*/
/*         {%- set classes = classes|merge([options.lastClass]) %}*/
/*     {%- endif %}*/
/* */
/* {# building the class of the children #}*/
/*     {%- set childrenClasses = item.childrenAttribute('class') is not empty ? [item.childrenAttribute('class')] : [] %}*/
/*     {%- set childrenClasses = childrenClasses|merge(['menu_level_' ~ item.level]) %}*/
/* */
/* {# adding classes for dropdown #}*/
/*     {%- if is_dropdown %}*/
/*         {%- set classes = classes|merge(['dropdown']) %}*/
/*         {%- set childrenClasses = childrenClasses|merge(['dropdown-menu']) %}*/
/*     {%- endif %}*/
/* */
/* {# putting classes together #}*/
/*     {%- if classes is not empty %}*/
/*         {%- set attributes = attributes|merge({'class': classes|join(' ')}) %}*/
/*     {%- endif %}*/
/*     {%- set listAttributes = item.childrenAttributes|merge({'class': childrenClasses|join(' ') }) %}*/
/* */
/* {# displaying the item #}*/
/*     <li{{ macros.attributes(attributes) }}>*/
/*         {%- if is_dropdown %}*/
/*             {{ block('dropdownElement') }}*/
/*         {%- elseif item.uri is not empty and (not item.current or options.currentAsLink) %}*/
/*             {{ block('linkElement') }}*/
/*         {%- else %}*/
/*             {{ block('spanElement') }}*/
/*         {%- endif %}*/
/* {# render the list of children#}*/
/*         {{ block('list') }}*/
/*     </li>*/
/*     */
/*     {%- if divider_append %}*/
/*         {{ block('dividerElement') }}*/
/*     {%- endif %}*/
/* {% endif %}*/
/* {% endblock %}*/
/* */
/* {% block dividerElement %}*/
/* {% if item.level == 1 %}*/
/*     <li class="divider-vertical"></li>*/
/* {% else %}*/
/*     <li class="divider"></li>*/
/* {% endif %}*/
/* {% endblock %}*/
/* */
/* {% block dropdownElement %}*/
/*     {%- set classes = item.linkAttribute('class') is not empty ? [item.linkAttribute('class')] : [] %}*/
/*     {%- set classes = classes|merge(['dropdown-toggle']) %}*/
/*     {%- set attributes = item.linkAttributes %}*/
/*     {%- set attributes = attributes|merge({'class': classes|join(' ')}) %}*/
/*     {%- set attributes = attributes|merge({'data-toggle': 'dropdown'}) %}*/
/*     <a href="#"{{ macros.attributes(attributes) }}>{{ block('label') }} <b class="caret"></b></a>*/
/* {% endblock %}*/
/* */
/* */
