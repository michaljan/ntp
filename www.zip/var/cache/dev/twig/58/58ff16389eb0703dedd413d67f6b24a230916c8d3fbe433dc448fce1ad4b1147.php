<?php

/* FOSUserBundle:ChangePassword:changePassword.html.twig */
class __TwigTemplate_1ab96a86d9a3353209f544303c10dd3a8dc490bfb58c77b0174dc609eedc39b5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_72d2daa2e17249bfe37071571dc5af4e8cc564a431f468c071723e722c82ba74 = $this->env->getExtension("native_profiler");
        $__internal_72d2daa2e17249bfe37071571dc5af4e8cc564a431f468c071723e722c82ba74->enter($__internal_72d2daa2e17249bfe37071571dc5af4e8cc564a431f468c071723e722c82ba74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:changePassword.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_72d2daa2e17249bfe37071571dc5af4e8cc564a431f468c071723e722c82ba74->leave($__internal_72d2daa2e17249bfe37071571dc5af4e8cc564a431f468c071723e722c82ba74_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_42b4f6a14826371442bda370e56b37abcaa726514be77ad9255793c73ea5b062 = $this->env->getExtension("native_profiler");
        $__internal_42b4f6a14826371442bda370e56b37abcaa726514be77ad9255793c73ea5b062->enter($__internal_42b4f6a14826371442bda370e56b37abcaa726514be77ad9255793c73ea5b062_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:ChangePassword:changePassword_content.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 4)->display($context);
        
        $__internal_42b4f6a14826371442bda370e56b37abcaa726514be77ad9255793c73ea5b062->leave($__internal_42b4f6a14826371442bda370e56b37abcaa726514be77ad9255793c73ea5b062_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:changePassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:ChangePassword:changePassword_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
