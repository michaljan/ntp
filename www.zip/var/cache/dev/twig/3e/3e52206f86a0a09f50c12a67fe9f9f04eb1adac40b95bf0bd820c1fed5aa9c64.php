<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_c10a68934d3dde744dee902c0d19a248869afa62e4ad811f944cee8ec30fd0e9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_047424d9d3b16dd00b4b92425cbbc5e60c445021197244d812eff489b803984b = $this->env->getExtension("native_profiler");
        $__internal_047424d9d3b16dd00b4b92425cbbc5e60c445021197244d812eff489b803984b->enter($__internal_047424d9d3b16dd00b4b92425cbbc5e60c445021197244d812eff489b803984b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_047424d9d3b16dd00b4b92425cbbc5e60c445021197244d812eff489b803984b->leave($__internal_047424d9d3b16dd00b4b92425cbbc5e60c445021197244d812eff489b803984b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
