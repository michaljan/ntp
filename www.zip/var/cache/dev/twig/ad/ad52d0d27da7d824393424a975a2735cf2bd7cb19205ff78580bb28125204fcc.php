<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_799be88c68837a067635a9b515e6395e3c4f6ae5a4148d205674ea59449b9313 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e50e87a67099d8d4b8bd76c8f3418345efa7d5ec913d5f4a81bc3cf8c356e27a = $this->env->getExtension("native_profiler");
        $__internal_e50e87a67099d8d4b8bd76c8f3418345efa7d5ec913d5f4a81bc3cf8c356e27a->enter($__internal_e50e87a67099d8d4b8bd76c8f3418345efa7d5ec913d5f4a81bc3cf8c356e27a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_e50e87a67099d8d4b8bd76c8f3418345efa7d5ec913d5f4a81bc3cf8c356e27a->leave($__internal_e50e87a67099d8d4b8bd76c8f3418345efa7d5ec913d5f4a81bc3cf8c356e27a_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
