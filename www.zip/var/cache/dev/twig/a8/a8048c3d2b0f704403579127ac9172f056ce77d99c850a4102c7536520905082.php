<?php

/* @FOSUser/Profile/edit.html.twig */
class __TwigTemplate_faf42086eb16b1e1549cc93d59ce582575ef53026025eaece4149d06ab7cacf6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "@FOSUser/Profile/edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_337437fb4dace562729da6ba2a7400d7d68cb2466da84f40cc24477f6a3f8cc4 = $this->env->getExtension("native_profiler");
        $__internal_337437fb4dace562729da6ba2a7400d7d68cb2466da84f40cc24477f6a3f8cc4->enter($__internal_337437fb4dace562729da6ba2a7400d7d68cb2466da84f40cc24477f6a3f8cc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@FOSUser/Profile/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_337437fb4dace562729da6ba2a7400d7d68cb2466da84f40cc24477f6a3f8cc4->leave($__internal_337437fb4dace562729da6ba2a7400d7d68cb2466da84f40cc24477f6a3f8cc4_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_9e9dd7b5c19e16b1d2f378aaf0c58a675620aa3233417b91aef5b5041d5d9b1f = $this->env->getExtension("native_profiler");
        $__internal_9e9dd7b5c19e16b1d2f378aaf0c58a675620aa3233417b91aef5b5041d5d9b1f->enter($__internal_9e9dd7b5c19e16b1d2f378aaf0c58a675620aa3233417b91aef5b5041d5d9b1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:edit_content.html.twig", "@FOSUser/Profile/edit.html.twig", 4)->display($context);
        
        $__internal_9e9dd7b5c19e16b1d2f378aaf0c58a675620aa3233417b91aef5b5041d5d9b1f->leave($__internal_9e9dd7b5c19e16b1d2f378aaf0c58a675620aa3233417b91aef5b5041d5d9b1f_prof);

    }

    public function getTemplateName()
    {
        return "@FOSUser/Profile/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
