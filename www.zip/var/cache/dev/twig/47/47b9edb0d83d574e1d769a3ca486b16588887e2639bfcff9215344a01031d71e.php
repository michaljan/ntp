<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_79158c8d3d23b8a8d33dd5672464484a0b66302dddd454028400903f7d678cb9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a193261bc9c7c585f077fe8e749ef98d5dcc62e00ac17686c28d692132f8dba = $this->env->getExtension("native_profiler");
        $__internal_6a193261bc9c7c585f077fe8e749ef98d5dcc62e00ac17686c28d692132f8dba->enter($__internal_6a193261bc9c7c585f077fe8e749ef98d5dcc62e00ac17686c28d692132f8dba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_6a193261bc9c7c585f077fe8e749ef98d5dcc62e00ac17686c28d692132f8dba->leave($__internal_6a193261bc9c7c585f077fe8e749ef98d5dcc62e00ac17686c28d692132f8dba_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
