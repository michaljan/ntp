<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_cdfdb30ac0ea5a297c61160573845d9561f747bbd90ad24319f68814f89cc932 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d697258088cbd0ce95e1a0bf98fc79f6b59c771bb396d36f606f7373b2deb5a9 = $this->env->getExtension("native_profiler");
        $__internal_d697258088cbd0ce95e1a0bf98fc79f6b59c771bb396d36f606f7373b2deb5a9->enter($__internal_d697258088cbd0ce95e1a0bf98fc79f6b59c771bb396d36f606f7373b2deb5a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_d697258088cbd0ce95e1a0bf98fc79f6b59c771bb396d36f606f7373b2deb5a9->leave($__internal_d697258088cbd0ce95e1a0bf98fc79f6b59c771bb396d36f606f7373b2deb5a9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */
