<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_47108b7754114d34b841896763da90c175fe654c107e6b59981ff50586177fb9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51c40e455bde459b78d1e54645c4265f3b57429374a179c9850c149b2439a297 = $this->env->getExtension("native_profiler");
        $__internal_51c40e455bde459b78d1e54645c4265f3b57429374a179c9850c149b2439a297->enter($__internal_51c40e455bde459b78d1e54645c4265f3b57429374a179c9850c149b2439a297_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_51c40e455bde459b78d1e54645c4265f3b57429374a179c9850c149b2439a297->leave($__internal_51c40e455bde459b78d1e54645c4265f3b57429374a179c9850c149b2439a297_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
