<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_6e2a883259b1225621f8ca32f9f7e19391a1a1949359eac1911a374a2bd95e84 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_83a8dd7ad1599d4db959de0251277b257fdbe7231bfcef2f03cc77f6a39f4560 = $this->env->getExtension("native_profiler");
        $__internal_83a8dd7ad1599d4db959de0251277b257fdbe7231bfcef2f03cc77f6a39f4560->enter($__internal_83a8dd7ad1599d4db959de0251277b257fdbe7231bfcef2f03cc77f6a39f4560_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_83a8dd7ad1599d4db959de0251277b257fdbe7231bfcef2f03cc77f6a39f4560->leave($__internal_83a8dd7ad1599d4db959de0251277b257fdbe7231bfcef2f03cc77f6a39f4560_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
