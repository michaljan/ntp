<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_0534daa2f33fd1b934339f02ca06662f660e24fe839a88d51a9f6943b11d205a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4f5852b21537a93530b6fa26cdf452d1704e0c430dc5ae63b238a7332ac0e244 = $this->env->getExtension("native_profiler");
        $__internal_4f5852b21537a93530b6fa26cdf452d1704e0c430dc5ae63b238a7332ac0e244->enter($__internal_4f5852b21537a93530b6fa26cdf452d1704e0c430dc5ae63b238a7332ac0e244_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_4f5852b21537a93530b6fa26cdf452d1704e0c430dc5ae63b238a7332ac0e244->leave($__internal_4f5852b21537a93530b6fa26cdf452d1704e0c430dc5ae63b238a7332ac0e244_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
