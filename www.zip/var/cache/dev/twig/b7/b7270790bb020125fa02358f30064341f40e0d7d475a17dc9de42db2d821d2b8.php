<?php

/* NTPBundle:Default:index.html.twig */
class __TwigTemplate_74c6258b5af47026c0bd24ac48f7c7fc1fee1bdf9c787541480d2741809f1530 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("NTPBundle::base.html.twig", "NTPBundle:Default:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "NTPBundle::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a79c370cf283bd74d6644ff008a55e83014cf34eb748f7bf0cfdbda996423816 = $this->env->getExtension("native_profiler");
        $__internal_a79c370cf283bd74d6644ff008a55e83014cf34eb748f7bf0cfdbda996423816->enter($__internal_a79c370cf283bd74d6644ff008a55e83014cf34eb748f7bf0cfdbda996423816_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "NTPBundle:Default:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a79c370cf283bd74d6644ff008a55e83014cf34eb748f7bf0cfdbda996423816->leave($__internal_a79c370cf283bd74d6644ff008a55e83014cf34eb748f7bf0cfdbda996423816_prof);

    }

    // line 2
    public function block_body($context, array $blocks = array())
    {
        $__internal_fc3e588c19a58ac8aa07dcc5c9bde6aafa97476eda13b74c88ecc2ecd1e7993e = $this->env->getExtension("native_profiler");
        $__internal_fc3e588c19a58ac8aa07dcc5c9bde6aafa97476eda13b74c88ecc2ecd1e7993e->enter($__internal_fc3e588c19a58ac8aa07dcc5c9bde6aafa97476eda13b74c88ecc2ecd1e7993e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 3
        echo "    <p>Hello Twig</p>
";
        
        $__internal_fc3e588c19a58ac8aa07dcc5c9bde6aafa97476eda13b74c88ecc2ecd1e7993e->leave($__internal_fc3e588c19a58ac8aa07dcc5c9bde6aafa97476eda13b74c88ecc2ecd1e7993e_prof);

    }

    public function getTemplateName()
    {
        return "NTPBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 3,  34 => 2,  11 => 1,);
    }
}
/* {% extends 'NTPBundle::base.html.twig' %}*/
/* {% block body %}*/
/*     <p>Hello Twig</p>*/
/* {% endblock %}*/
/* */
