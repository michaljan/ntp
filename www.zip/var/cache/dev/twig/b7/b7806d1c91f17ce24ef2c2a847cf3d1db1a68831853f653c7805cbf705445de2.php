<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_c3f3e5d07abd19769b9d82f3e08802e2051855461225193f707f8c802fecd3a8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a7ac0db2ea8861ecd402b7678cf27d41b0c613e5e2706937334894b74bd6be94 = $this->env->getExtension("native_profiler");
        $__internal_a7ac0db2ea8861ecd402b7678cf27d41b0c613e5e2706937334894b74bd6be94->enter($__internal_a7ac0db2ea8861ecd402b7678cf27d41b0c613e5e2706937334894b74bd6be94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a7ac0db2ea8861ecd402b7678cf27d41b0c613e5e2706937334894b74bd6be94->leave($__internal_a7ac0db2ea8861ecd402b7678cf27d41b0c613e5e2706937334894b74bd6be94_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_da04ebceb91fe80daad2ed7949102d3cca59e2c8ad6cec6752fd85360f4217ad = $this->env->getExtension("native_profiler");
        $__internal_da04ebceb91fe80daad2ed7949102d3cca59e2c8ad6cec6752fd85360f4217ad->enter($__internal_da04ebceb91fe80daad2ed7949102d3cca59e2c8ad6cec6752fd85360f4217ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_da04ebceb91fe80daad2ed7949102d3cca59e2c8ad6cec6752fd85360f4217ad->leave($__internal_da04ebceb91fe80daad2ed7949102d3cca59e2c8ad6cec6752fd85360f4217ad_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:reset_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
